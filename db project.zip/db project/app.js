const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const session = require('express-session');
const fs = require('fs');

// Read the image file
const imageFile = fs.readFileSync('Designer.png');

// Convert to base64
const base64Image = imageFile.toString('base64');





// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Your MySQL username
    password: '1209', // Your MySQL password
    database: 'project', // Database name
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to MySQL database.');
});

const app = express();
app.use(session({
    secret: 'your-secret-key', // Replace with a strong secret
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set `true` if using HTTPS
}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Home Page
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .bg-image {
            background-image: url('data:image/png;base64,${base64Image}');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
        }

        .content {
            position: relative;
            z-index: 10;
            text-align: center;
            color: white;
            padding: 30px;
            border-radius: 15px;
            background-color: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
        }

        .content h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            font-weight: bold;
            color: #f0f0f0;
        }

        .content p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #e0e0e0;
        }

        .btn-custom {
            margin: 0 15px;
            padding: 12px 30px;
            font-size: 1.1rem;
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08);
        }
    </style>
</head>
<body>
    <div class="bg-image">
        <div class="overlay"></div>
        <div class="content container">
            <h1>Vendor Management System</h1>
            <p>Streamline vendor compliance, certification, and management with our comprehensive platform</p>
            <div>
                <a href="/login" class="btn btn-primary btn-custom">Login</a>
                <a href="/signup" class="btn btn-success btn-custom">Signup</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional, but recommended for full functionality) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `);
});

// Login Page
app.get('/login', (req, res) => {
    res.send(`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Management System - Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-container {
            height: 100vh;
            display: flex;
        }

        .login-image {
            background-image: url('data:image/png;base64,${base64Image}');
            background-size: cover;
            background-position: center;
            width: 50%;
        }

        .login-form {
            width: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f6f9;
            padding: 30px;
        }

        .login-content {
            width: 100%;
            max-width: 400px;
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h2 {
            color: #333;
            font-weight: bold;
        }

        .form-control {
            border-radius: 25px;
            padding: 10px 20px;
        }

        .btn-login {
            width: 100%;
            border-radius: 25px;
            padding: 10px;
            background-color: #007bff;
            border: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .login-footer {
            text-align: center;
            margin-top: 20px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }

            .login-image, .login-form {
                width: 100%;
                height: 50vh;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-image"></div>
        <div class="login-form">
            <div class="login-content">
                <div class="login-header">
                    <h2>Vendor Management System</h2>
                    <p class="text-muted">Login to your account</p>
                </div>
                <form action="/login" method="POST">
                    <div class="form-group">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                    </div>
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-login">Login</button>
                </form>
                <div class="login-footer">
                    <p class="text-muted">Don't have an account? <a href="/signup">Sign up</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `);
});

// Handle Login Submission
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    const query = 'SELECT * FROM User WHERE Email = ? AND Password = ?';
    db.query(query, [email, password], (err, results) => {
        if (err) {
            console.error('Error during login:', err);
            return res.status(500).send('<h1>Login failed. Please try again later.</h1>');
        }


        if (results.length > 0) {
            const user = results[0];
            req.session.user = {
                id: user.UserID,
                email: user.Email,
                role: user.Role
            };
            
            
            if (user.Role === 'Vendor') {
                res.redirect('/vendor-dashboard');
            } else if (user.Role === 'Budget Manager' || user.Role === 'Finance Team') {
                res.redirect('/Budget-Manager');
            } else if (user.Role === 'Department Head') {
                res.redirect('/department-head-dashboard');
            } else if (user.Role === 'Procurement Manager') {
                res.redirect('/procurement-manager-dashboard');
            }
        } else {
            res.send(`
                <h1>Invalid email or password. Please try again.</h1>
                <form method="POST" action="/login">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required />
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required />
                    <button type="submit">Login</button>
                </form>
            `);
        }
    });
});
app.get('/vendor-dashboard', (req, res) => {
    res.send(`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Dashboard</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        :root {
            --bg-primary: #0f1c2e;
            --bg-secondary: #1a2b3c;
            --accent-color: #38b2ac;
            --text-primary: #e0e6ed;
            --text-secondary: #8899a6;
        }

        * {
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .glass-navbar {
            background: rgba(26, 43, 60, 0.8);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(56, 178, 172, 0.1);
            padding: 15px 0;
        }

        .nav-link {
            color: var(--text-secondary) !important;
            position: relative;
            font-weight: 500;
            letter-spacing: 0.5px;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--accent-color) !important;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 50%;
            background-color: var(--accent-color);
            transition: all 0.3s ease;
        }

        .nav-link:hover::before {
            width: 100%;
            left: 0;
        }

        .dropdown-menu {
            background-color: var(--bg-secondary);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .dropdown-item {
            color: var(--text-secondary);
            background-color: transparent;
        }

        .dropdown-item:hover {
            background-color: rgba(56, 178, 172, 0.1);
            color: var(--accent-color);
        }

        .dashboard-card {
            background-color: var(--bg-secondary);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            border: 1px solid rgba(56, 178, 172, 0.1);
        }

        .btn-dashboard {
            background-color: var(--accent-color);
            color: var(--bg-primary);
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
        }

        .btn-dashboard::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(120deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: all 0.6s;
        }

        .btn-dashboard:hover::before {
            left: 100%;
        }

        .btn-dashboard:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(56, 178, 172, 0.2);
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }

        .floating-element {
            animation: float 4s ease-in-out infinite;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }
            .dashboard-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg glass-navbar">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="#">
                <span class="floating-element">🚀</span> Vendor Dashboard
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/notifications">Notifications</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            Contracts
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/contract">View Contracts</a></li>
                            <li><a class="dropdown-item" href="/check-renewals">Check Renewals</a></li>
                            <li><a class="dropdown-item" href="/add-contract">Add New Contract</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            Budget
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/view-budget">Budget Table</a></li>
                            <li><a class="dropdown-item" href="/check-budget-alerts">Budget Alerts</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/profile">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="/logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="dashboard-card mt-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-3">Welcome, Vendor</h1>
                    <p class="text-secondary mb-4">Manage your contracts, budgets, and performance efficiently.</p>
                    <button class="btn btn-dashboard" onclick="location.href='/vendor-performance'">
                        View Performance Insights
                    </button>
                </div>
                <div class="col-md-4 text-end d-none d-md-block floating-element">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
                        <defs>
                            <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#38b2ac;stop-opacity:0.8" />
                                <stop offset="100%" style="stop-color:#2c7a7b;stop-opacity:0.6" />
                            </linearGradient>
                        </defs>
                        <circle cx="100" cy="100" r="90" fill="url(#grad)" />
                        <text x="50%" y="50%" text-anchor="middle" fill="white" font-size="40" font-weight="bold">
                            V+
                        </text>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `);
});
app.get('/add-contract', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Redirect to login if not logged in
    }

    const { id } = req.session.user; // User ID from session

    // Fetch vendor and department details for the logged-in user
    const query = `
        SELECT 
            v.VendorID,
            d.DepartmentID
        FROM 
            User u
        JOIN 
            Vendor v ON u.UserID = v.UserID
        JOIN 
            Department d ON u.DepartmentName = d.DepartmentName
        WHERE 
            u.UserID = ?;
    `;

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching vendor and department details:', err);
            return res.status(500).send('Error fetching details.');
        }

        if (results.length === 0) {
            return res.send('<h1>No vendor or department details found for the user.</h1>');
        }

        const { VendorID, DepartmentID } = results[0];

        // Render form
        res.send(`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Contract</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --background-color: #f4f6f7;
            --text-color: #333;
            --border-radius: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            padding: 30px;
        }

        h1 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 25px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--primary-color);
            font-weight: 500;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            transition: border-color 0.3s ease;
            font-size: 16px;
        }

        input:focus, 
        select:focus, 
        textarea:focus {
            outline: none;
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 18px;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .submit-btn:hover {
            background-color: #2980b9;
        }

        .submit-btn:active {
            transform: scale(0.98);
        }

        @media (max-width: 600px) {
            .container {
                width: 95%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add Contract</h1>
        <form action="/submit-contract" method="POST">
            <input type="hidden" name="VendorID" value="${VendorID}">
            <input type="hidden" name="DepartmentID" value="${DepartmentID}">

            <div class="form-group">
                <label for="Terms">Terms</label>
                <textarea name="Terms" id="Terms" required></textarea>
            </div>

            <div class="form-group">
                <label for="ContractType">Contract Type</label>
                <select name="ContractType" id="ContractType" required>
                    <option value="Fixed-Term">Fixed-Term</option>
                    <option value="Open-Ended">Open-Ended</option>
                </select>
            </div>

            <div class="form-group">
                <label for="Conditions">Conditions</label>
                <textarea name="Conditions" id="Conditions" required></textarea>
            </div>

            <div class="form-group">
                <label for="SpecialClauses">Special Clauses</label>
                <textarea name="SpecialClauses" id="SpecialClauses" required></textarea>
            </div>

            <div class="form-group">
                <label for="RenewalDate">Renewal Date</label>
                <input type="date" name="RenewalDate" id="RenewalDate" required>
            </div>

            <div class="form-group">
                <label for="ExpiryDate">Expiry Date</label>
                <input type="date" name="ExpiryDate" id="ExpiryDate" required>
            </div>

            <div class="form-group">
                <label for="IsRenewed">Is Renewed</label>
                <select name="IsRenewed" id="IsRenewed" required>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>

            <div class="form-group">
                <label for="IsContractArchived">Is Contract Archived</label>
                <select name="IsContractArchived" id="IsContractArchived" required>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>

            <button type="submit" class="submit-btn">Submit Contract</button>
        </form>
    </div>
</body>
</html>        `);
    });
});

app.post('/submit-contract', (req, res) => {
    const {
        VendorID,
        DepartmentID,
        Terms,
        ContractType,
        Conditions,
        SpecialClauses,
        RenewalDate,
        ExpiryDate,
        IsRenewed,
        IsContractArchived
    } = req.body;

    const query = `
        INSERT INTO Contract (
            VendorID, DepartmentID, Terms, ContractType, 
            Conditions, SpecialClauses, RenewalDate, ExpiryDate, 
            IsRenewed, IsContractArchived
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `;

    db.query(query, [
        VendorID, DepartmentID, Terms, ContractType,
        Conditions, SpecialClauses, RenewalDate, ExpiryDate,
        IsRenewed, IsContractArchived
    ], (err) => {
        if (err) {
            console.error('Error inserting contract:', err);
            return res.status(500).send('Error inserting contract.');
        }

        res.redirect('/vendor-dashboard');
    });
});

app.get('/check-budget-alerts', (req, res) => {  
    if (!req.session.user) {
        return res.redirect('/login'); // Redirect to login if the user is not logged in
    }

    const { id } = req.session.user; // Get the logged-in user's ID

    // Query to fetch purchase orders that have exceeded their assigned budget
    const budgetAlertQuery = `
        SELECT 
            po.PurchaseOrderID,
            po.DepartmentID,
            po.VendorID,
            po.ItemDetails,
            po.Quantity,
            po.ServicesOrdered,
            po.TotalCost,
            po.BudgetID,
            po.IsWithinBudget,
            po.BudgetDeviation,
            v.OrganizationName AS VendorName,
            d.DepartmentName
        FROM 
            PurchaseOrder po
        JOIN 
            Vendor v ON po.VendorID = v.VendorID
        JOIN 
            Department d ON po.DepartmentID = d.DepartmentID
        WHERE
        
        
            po.IsWithinBudget = 0;  -- Fetch only those purchase orders where the budget was exceeded
    `;

    db.query(budgetAlertQuery, (err, budgetAlerts) => {
        if (err) {
            console.error('Error fetching budget alert details:', err);
            return res.status(500).send('Error fetching budget alerts.');
        }

        if (budgetAlerts.length === 0) {
            return res.send(`
                <h1>No purchase orders have exceeded their assigned budget.</h1>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            `);
        }

        // Notify users about purchase orders exceeding budget
        const notificationInsertQuery = `
            INSERT INTO Notification (UserID, Message)
            VALUES (?, ?);
        `;
        budgetAlerts.forEach(alert => {
            const message = `Purchase Order ID ${alert.PurchaseOrderID} has exceeded its assigned budget by ${alert.BudgetDeviation}.`;
            db.query(notificationInsertQuery, [id, message], err => {
                if (err) {
                    console.error('Error sending notification:', err);
                }
            });
        });

        // Render the budget alert details
        const budgetAlertHTML = budgetAlerts.map(alert => `
            <div style="margin-bottom: 20px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
                <h2>Purchase Order ID: ${alert.PurchaseOrderID}</h2>
                <p><strong>Vendor Name:</strong> ${alert.VendorName}</p>
                <p><strong>Department Name:</strong> ${alert.DepartmentName}</p>
                <p><strong>Item Details:</strong> ${alert.ItemDetails}</p>
                <p><strong>Quantity:</strong> ${alert.Quantity}</p>
                <p><strong>Services Ordered:</strong> ${alert.ServicesOrdered}</p>
                <p><strong>Total Cost:</strong> ${alert.TotalCost}</p>
                <p><strong>Budget ID:</strong> ${alert.BudgetID}</p>
                <p><strong>Budget Deviation:</strong> ${alert.BudgetDeviation}</p>
            </div>
        `).join('');

        res.send(`
            <h1>Budget Alerts: Purchase Orders Exceeding Budget</h1>
            ${budgetAlertHTML}
            <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
        `);
    });
});



app.get('/check-renewals', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Redirect to login if the user is not logged in
    }

    const { id } = req.session.user; // Get the logged-in user's ID
    const daysUntilExpiry = 30; // Specify the time frame to check for expiry

    const renewalQuery = `
        SELECT 
            c.ContractID,
            c.Terms,
            c.ContractType,
            c.Conditions,
            c.Status,
            c.RenewalDate,
            c.ExpiryDate,
            c.IsRenewed,
            c.IsContractArchived,
            v.OrganizationName AS VendorName,
            u.Name AS UserName,
            u.Email AS UserEmail
        FROM 
            Contract c
        JOIN 
            Vendor v ON c.VendorID = v.VendorID
        JOIN 
            User u ON v.UserID = u.UserID
        WHERE 
            u.UserID = ? 
            AND c.ExpiryDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY);
    `;

    db.query(renewalQuery, [id, daysUntilExpiry], (err, results) => {
        if (err) {
            console.error('Error fetching contract renewal details:', err);
            return res.status(500).send('Error fetching renewal details.');
        }

        if (results.length === 0) {
            return res.send(`
                <h1>No contracts are nearing expiry within the next ${daysUntilExpiry} days.</h1>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            `);
        }

        // Notify users about expiring contracts
        const notificationInsertQuery = `
            INSERT INTO Notification (UserID, Message)
            VALUES (?, ?);
        `;
        results.forEach(contract => {
            const message = `Contract ID ${contract.ContractID} is expiring on ${new Date(contract.ExpiryDate).toLocaleDateString()}.`;
            db.query(notificationInsertQuery, [id, message], err => {
                if (err) {
                    console.error('Error sending notification:', err);
                }
            });
        });

        // Render the renewal details
        const renewalHTML = results.map(contract => `
            <div style="margin-bottom: 20px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
                <h2>Contract ID: ${contract.ContractID}</h2>
                <p><strong>Vendor Name:</strong> ${contract.VendorName}</p>
                <p><strong>Terms:</strong> ${contract.Terms}</p>
                <p><strong>Contract Type:</strong> ${contract.ContractType}</p>
                <p><strong>Conditions:</strong> ${contract.Conditions}</p>
                <p><strong>Status:</strong> ${contract.Status}</p>
                <p><strong>Renewal Date:</strong> ${contract.RenewalDate ? new Date(contract.RenewalDate).toLocaleDateString() : 'N/A'}</p>
                <p><strong>Expiry Date:</strong> ${new Date(contract.ExpiryDate).toLocaleDateString()}</p>
                <p><strong>Is Renewed:</strong> ${contract.IsRenewed}</p>
                <p><strong>Is Archived:</strong> ${contract.IsContractArchived ? 'YES' : 'NO'}</p>
            </div>
        `).join('');

        res.send(`
            <h1>Contracts Nearing Expiry</h1>
            ${renewalHTML}
            <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.get('/view-budget', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');  // Redirect to login if the user is not logged in
    }
    const { id } = req.session.user;  // Access 'id' which contains the UserID

    // Query to fetch budget details for the given UserID
    const budgetQuery = `
        SELECT 
            b.BudgetID,
            v.VendorID,
            c.ContractID,
            d.DepartmentID,
            b.ExpenseCategory,
            b.TotalAmount,
            b.SpentAmount,
            b.RemainingAmount,
            b.Date,
            b.ExpenditureStatus,
            b.OverspendingStatus,
            b.AlertThreshold
        FROM 
            Budget b
        JOIN 
            Vendor v ON b.VendorID = v.VendorID
        JOIN 
            Contract c ON b.ContractID = c.ContractID
        JOIN 
            Department d ON b.DepartmentID = d.DepartmentID
        JOIN 
            User u ON v.UserID = u.UserID
        WHERE 
            u.UserID = ?;  -- Use the UserID stored in the session
    `;

    db.query(budgetQuery, [id], (err, budgetResults) => {
        if (err) {
            console.error('Error fetching budget details:', err);
            return res.status(500).send('Error fetching budget details.');
        }

        if (budgetResults.length === 0) {
            return res.send(`
                <h1>No budget details found for this vendor.</h1>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            `);
        }

        // Render the budget details in a styled table
        const budgetTableHTML = `
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        margin: 0;
                        padding: 0;
                    }
                    h1 {
                        text-align: center;
                        margin-top: 20px;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 20px;
                    }
                    table, th, td {
                        border: 1px solid #ddd;
                        padding: 8px;
                        text-align: left;
                    }
                    th {
                        background-color: #4CAF50;
                        color: white;
                    }
                    tr:nth-child(even) {
                        background-color: #f2f2f2;
                    }
                    tr:hover {
                        background-color: #ddd;
                    }
                    button {
                        padding: 10px 20px;
                        background-color: #4CAF50;
                        color: white;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        margin-top: 20px;
                    }
                    button:hover {
                        background-color: #45a049;
                    }
                </style>
            </head>
            <body>
                <h1>Budget Details</h1>
                <table>
                    <thead>
                        <tr>
                            <th>Budget ID</th>
                            <th>Vendor ID</th>
                            <th>Contract ID</th>
                            <th>Department ID</th>
                            <th>Expense Category</th>
                            <th>Total Amount</th>
                            <th>Spent Amount</th>
                            <th>Remaining Amount</th>
                            <th>Date</th>
                            <th>Expenditure Status</th>
                            <th>Overspending Status</th>
                            <th>Alert Threshold</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${budgetResults.map(budget => `
                            <tr>
                                <td>${budget.BudgetID}</td>
                                <td>${budget.VendorID}</td>
                                <td>${budget.ContractID}</td>
                                <td>${budget.DepartmentID}</td>
                                <td>${budget.ExpenseCategory}</td>
                                <td>${budget.TotalAmount}</td>
                                <td>${budget.SpentAmount}</td>
                                <td>${budget.RemainingAmount}</td>
                                <td>${budget.Date? new Date(budget.Date).toLocaleDateString() : 'N/A'}</td>
                                <td>${budget.ExpenditureStatus}</td>
                                <td>${budget.OverspendingStatus ? 'Yes' : 'No'}</td>
                                <td>${budget.AlertThreshold}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            </body>
            </html>
        `;

        res.send(budgetTableHTML);
    });
});


// Route for Vendor Performance
app.get('/vendor-performance', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');  // Redirect to login if the user is not logged in
    }
    const { id } = req.session.user;  // Access 'id' which contains the UserID

    
    // Fetch vendor performance data by joining User, Vendor, and VendorPerformance tables
    const performanceQuery = `
        SELECT 
            vp.PerformancePeriod, 
            vp.DeliveryTimeliness, 
            vp.ServiceQuality, 
            vp.Pricing, 
            vp.ComplianceAdherence, 
            vp.PerformanceRating
        FROM 
            User u
        INNER JOIN 
            Vendor v ON u.UserID = v.UserID
        INNER JOIN 
            VendorPerformance vp ON v.VendorID = vp.VendorID
        WHERE 
            u.UserID = ?
    `;

    db.query(performanceQuery, [id], (err, performanceResults) => {
        if (err) {
            console.error('Error fetching vendor performance:', err);
            return res.status(500).send('Error fetching vendor performance.');
        }

        if (performanceResults.length === 0) {
            return res.send(`
                <h1>No Performance found for this vendor.</h1>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            `);
        }

        // Prepare data for chart
        const periods = performanceResults.map(row => row.PerformancePeriod);
        const deliveryTimeliness = performanceResults.map(row => row.DeliveryTimeliness);
        const serviceQuality = performanceResults.map(row => row.ServiceQuality);
        const pricing = performanceResults.map(row => row.Pricing);
        const complianceAdherence = performanceResults.map(row => row.ComplianceAdherence);
        const performanceRating = performanceResults.map(row => row.PerformanceRating);

        // Generate the chart data
        const chartData = {
            labels: periods,
            datasets: [
                {
                    label: 'Delivery Timeliness',
                    data: deliveryTimeliness,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Service Quality',
                    data: serviceQuality,
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Pricing',
                    data: pricing,
                    backgroundColor: 'rgba(255, 159, 64, 0.2)',
                    borderColor: 'rgba(255, 159, 64, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Compliance Adherence',
                    data: complianceAdherence,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Performance Rating',
                    data: performanceRating,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }
            ]
        };

        const chartOptions = {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        };

        // Render the performance page with chart
        res.send(`
            <h1>Vendor Performance</h1>
            <canvas id="performanceChart" width="400" height="200"></canvas>
            <br>
            <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                const ctx = document.getElementById('performanceChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar', // Change the chart type to 'bar'
                    data: ${JSON.stringify(chartData)},
                    options: ${JSON.stringify(chartOptions)}
                });
            </script>
        `);
    });
});

app.get('/contract', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');  // Redirect to login if the user is not logged in
    }
    const { id } = req.session.user;  // Access 'id' which contains the UserID

   

    // Query to fetch contract details for the given UserID
    const contractQuery = `
        SELECT 
            u.Name AS UserName,
            u.Email AS UserEmail,
            v.OrganizationName AS VendorName,
            c.ContractID,
            c.Terms,
            c.ContractType,
            c.Conditions,
            c.Status,
            c.RenewalDate,
            c.ExpiryDate,
            c.IsRenewed,
            c.IsContractArchived,    -- Ensure IsContractArchived is selected
            c.ArchivedDate 
        FROM 
            User u
        JOIN 
            Vendor v ON u.UserID = v.UserID
        JOIN 
            Contract c ON v.VendorID = c.VendorID
        WHERE 
            u.UserID = ?;  -- Use the UserID stored in the session
    `;

    db.query(contractQuery, [id], (err, contractResults) => {
        if (err) {
            console.error('Error fetching contract details:', err);
            return res.status(500).send('Error fetching contract details.');
        }

        if (contractResults.length === 0) {
            return res.send(`
                <h1>No contract details found for this vendor.</h1>
                <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
            `);
        }

        // Render the contract details
        const contractHTML = contractResults.map(contract => `
            <div style="margin-bottom: 20px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
                <h2>Contract ID: ${contract.ContractID}</h2>
                <p><strong>Terms:</strong> ${contract.Terms }</p>
                <p><strong>Contract Type:</strong> ${contract.ContractType}</p>
                <p><strong>Conditions:</strong> ${contract.Conditions }</p>
                <p><strong>Status:</strong> ${contract.Status}</p>
                <p><strong>Renewal Date:</strong> ${contract.RenewalDate ? new Date(contract.RenewalDate).toLocaleDateString() : 'N/A'}</p>
                <p><strong>Expiry Date:</strong> ${contract.ExpiryDate ? new Date(contract.ExpiryDate).toLocaleDateString() : 'N/A'}</p>
                <p><strong>Is Renewed:</strong> ${contract.IsRenewed }</p>
                <p><strong>Is Archived:</strong> ${contract.IsContractArchived}</p>
               <p><strong>Archived Date:</strong> ${contract.ArchivedDate ? new Date(contract.ArchivedDate).toLocaleDateString() : 'N/A'}</p>

            </div>
        `).join('');
        

        res.send(`
            <h1>Vendor Contracts</h1>
            ${contractHTML}
            <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.get('/notifications', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Redirect to login if the user is not logged in
    }
    const { id } = req.session.user; // Get the UserID from the session

    // Query to fetch notifications for the logged-in user
    const notificationQuery = `
        SELECT 
            NotificationID,
            Message,
            Date
        FROM 
            Notification
        WHERE 
            UserID = ?
        ORDER BY 
            Date DESC;
    `;

    db.query(notificationQuery, [id], (err, notifications) => {
        if (err) {
            console.error('Error fetching notifications:', err);
            return res.status(500).send('Error fetching notifications.');
        }

        if (notifications.length === 0) {
            return res.send(`
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Notifications</title>
                    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
                    <style>
                        body {
                            background-color: #f8f9fa;
                            color: #333;
                        }
                        .container {
                            margin-top: 20px;
                        }
                        .notification {
                            border: 1px solid #ccc;
                            padding: 10px;
                            border-radius: 5px;
                            margin-bottom: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1 class="text-center my-4">Notifications</h1>
                        <p class="text-center">No notifications found.</p>
                        <div class="text-center">
                            <button class="btn btn-primary" onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
                        </div>
                    </div>
                </body>
                </html>
            `);
        }

        // Render the notifications
        const notificationsHTML = notifications.map(notification => `
            <div class="notification">
                <p><strong>Date:</strong> ${new Date(notification.Date).toLocaleString()}</p>
                <p><strong>Message:</strong> ${notification.Message}</p>
            </div>
        `).join('');

        res.send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Notifications</title>
                <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    body {
                        background-color: #f8f9fa;
                        color: #333;
                    }
                    .container {
                        margin-top: 20px;
                    }
                    .notification {
                        border: 1px solid #ccc;
                        padding: 10px;
                        border-radius: 5px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1 class="text-center my-4">Notifications</h1>
                    ${notificationsHTML}
                    <div class="text-center">
                        <button class="btn btn-primary" onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
                    </div>
                </div>
            </body>
            </html>
        `);
    });
});

app.get('/profile', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');  // Redirect to login if the user is not logged in
    }
    const { id } = req.session.user;  // Access 'id' which contains the UserID


    // Query to fetch vendor profile details and certifications
    const vendorQuery = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            v.ServiceCategories,
            v.ContactName,
            v.ContactEmail,
            v.ContactPhone,
            v.ContactAddress,
            v.CNICNumber
        FROM 
            Vendor v
        INNER JOIN 
            User u ON v.UserID = u.UserID
        WHERE 
            u.UserID = ?
    `;

    // Query to fetch compliance certifications for the vendor
    const certificationsQuery = `
        SELECT 
            c.CertificationNumber, 
            c.CertificateName, 
            c.IssuedByCompany, 
            c.AttestedByPerson, 
            c.IssueDate, 
            c.ExpiryDate, 
            c.Status
        FROM 
            ComplianceCertifications c
        WHERE 
            c.VendorID = (SELECT VendorID FROM Vendor WHERE UserID = ?)
    `;

    // Execute both queries concurrently
    db.query(vendorQuery, [id], (err, vendorResults) => {
        if (err) {
            console.error('Error fetching vendor profile:', err);
            return res.status(500).send('Error fetching vendor profile.');
        }

        if (vendorResults.length === 0) {
            return res.send(`
                <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        .content {
            margin-top: 20px;
            padding: 20px;
        }
        .btn-custom {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-custom:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container content">
        <h1 class="text-center my-4">Vendor Profile</h1>
        <div class="alert alert-warning text-center" role="alert">
            No vendor data found for this user.
        </div>
        <div class="text-center">
            <button class="btn btn-custom mx-2" onclick="location.href='/add-vendor'">Add Vendor Details</button>
            <button class="btn btn-secondary mx-2" onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
            `);
        
        }

        const vendor = vendorResults[0]; // Only one vendor since UserID is unique

        db.query(certificationsQuery, [id], (err, certificationsResults) => {
            if (err) {
                console.error('Error fetching vendor certifications:', err);
                return res.status(500).send('Error fetching vendor certifications.');
            }

            // Render the profile page with vendor data and certifications
            res.send(`
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 0;
                            padding: 0;
                        }
                        .content {
                            margin-top: 20px;
                            padding: 20px;
                        }
                        .profile-section {
                            margin-bottom: 20px;
                        }
                        table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        table, th, td {
                            border: 1px solid black;
                        }
                        th, td {
                            padding: 10px;
                            text-align: left;
                        }
                        button {
                            background-color: #4CAF50;
                            color: white;
                            padding: 10px 20px;
                            border: none;
                            border-radius: 5px;
                            cursor: pointer;
                        }
                        button:hover {
                            background-color: #45a049;
                        }
                    </style>
                </head>
                <body>
                    <div class="content">
                        <h1>Vendor Profile</h1>
                        
                        <!-- Vendor Information -->
                        <div class="profile-section">
                            <h2>Vendor Information</h2>
                            <p><strong>Organization Name:</strong> ${vendor.OrganizationName}</p>
                            <p><strong>Service Categories:</strong> ${vendor.ServiceCategories}</p>
                            <p><strong>Contact Name:</strong> ${vendor.ContactName}</p>
                            <p><strong>Contact Email:</strong> ${vendor.ContactEmail}</p>
                            <p><strong>Contact Phone:</strong> ${vendor.ContactPhone}</p>
                            <p><strong>Contact Address:</strong> ${vendor.ContactAddress}</p>
                            <p><strong>CNIC Number:</strong> ${vendor.CNICNumber}</p>
                        </div>
                        
                        <!-- Compliance Certifications -->
                        <div class="profile-section">
                            <h2>Compliance Certifications</h2>
                            ${certificationsResults.length > 0 ? `
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Certification Number</th>
                                            <th>Certificate Name</th>
                                            <th>Issued By</th>
                                            <th>Attested By</th>
                                            <th>Issue Date</th>
                                            <th>Expiry Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${certificationsResults.map(cert => `
                                            <tr>
                                                <td>${cert.CertificationNumber}</td>
                                                <td>${cert.CertificateName}</td>
                                                <td>${cert.IssuedByCompany}</td>
                                                <td>${cert.AttestedByPerson}</td>
                                                <td>${cert.IssueDate}</td>
                                                <td>${cert.ExpiryDate}</td>
                                                <td>${cert.Status}</td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            ` : '<p>No certifications found for this vendor.</p>'}
                        </div>

                        <!-- Button to go back to the dashboard -->
                        <button onclick="location.href='/vendor-dashboard'">Back to Dashboard</button>
                    </div>
                </body>
                </html>
            `);
        });
    });
});
app.get('/add-vendor', (req, res) => {
    res.send(`
        <form action="/submit1" method="POST">
            <h2>Vendor Information</h2>
            Organization Name: <input type="text" name="organizationName" required><br>
            Service Categories: <input type="text" name="serviceCategories"><br>
            Contact Name: <input type="text" name="contactName"><br>
            Contact Email: <input type="email" name="contactEmail" required><br>
            Contact Phone: <input type="text" name="contactPhone" required><br>
            Contact Address: <input type="text" name="contactAddress"><br>
            CNIC Number: <input type="text" name="cnicNumber" required><br>
            
            <h2>Compliance Certification</h2>
            Certification Number: <input type="text" name="certificationNumber" required><br>
            Certificate Name: <input type="text" name="certificateName" required><br>
            Issued By Company: <input type="text" name="issuedByCompany" required><br>
            Attested By Person: <input type="text" name="attestedByPerson" required><br>
            Issue Date: <input type="date" name="issueDate" required><br>
            Expiry Date: <input type="date" name="expiryDate" required><br>
            Status: 
            <select name="status" required>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Under Review">Under Review</option>
            </select><br>
            <button type="submit">Submit</button>
        </form>
    `);
});


app.post('/submit1', (req, res) => {
    const {
        organizationName,
        serviceCategories,
        contactName,
        contactEmail,
        contactPhone,
        contactAddress,
        cnicNumber,
        certificationNumber,
        certificateName,
        issuedByCompany,
        attestedByPerson,
        issueDate,
        expiryDate,
        status,
    } = req.body;

    // Insert Vendor
    const { id } = req.session.user;
    const vendorQuery = `
        INSERT INTO Vendor 
        (OrganizationName, ServiceCategories, ContactName, ContactEmail, ContactPhone, ContactAddress, CNICNumber,UserID) 
        VALUES (?, ?, ?, ?, ?, ?, ?,?)
    `;

    db.query(
        vendorQuery,
        [organizationName, serviceCategories, contactName, contactEmail, contactPhone, contactAddress, cnicNumber,id],
        (err, vendorResult) => {
            if (err) {
                console.error('Error inserting vendor:', err);
                return res.status(500).send('Error inserting vendor.');
            }

            const vendorID = vendorResult.insertId;

            // Insert Compliance Certification
            const certificationQuery = `
                INSERT INTO ComplianceCertifications 
                (CertificationNumber, CertificateName, IssuedByCompany, AttestedByPerson, IssueDate, ExpiryDate, Status, VendorID) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;

            db.query(
                certificationQuery,
                [certificationNumber, certificateName, issuedByCompany, attestedByPerson, issueDate, expiryDate, status, vendorID],
                (err) => {
                    if (err) {
                        console.error('Error inserting certification:', err);
                        return res.status(500).send('Error inserting certification.');
                    }

                    // Successful insertion
                    res.redirect('/vendor-dashboard'); // Redirect on success
                  
                }
            );
        }
    );
});

app.get('/Budget-Manager', (req, res) => {
    const query = `
        SELECT v.VendorID, v.ContactName, v.ServiceCategories, b.ContractID, b.TotalAmount, b.SpentAmount, b.RemainingAmount, b.ExpenditureStatus
        FROM Budget b
        JOIN Vendor v ON b.VendorID = v.VendorID
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching budget data:', err);
            return res.status(500).send('Error fetching budget data.');
        }

        if (!results || results.length === 0) {
            return res.status(404).send('<h2>No budget data found.</h2>');
        }

        let html = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Vendor Budget Manager Dashboard</title>
                <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f8f9fa;
                        color: #333;
                    }
                    .container {
                        margin-top: 20px;
                    }
                    .table-container {
                        display: none;
                        margin-top: 20px;
                    }
                    .btn-toggle {
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1 class="text-center my-4">Vendor Budget Manager Dashboard</h1>
                    <div class="text-center">
                        <button class="btn btn-primary btn-toggle" onclick="toggleTable()">Show/Hide Budget Table</button>
                    </div>
                    <div class="table-container" id="budgetTable">
                        <table class="table table-bordered table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Vendor Contact</th>
                                    <th>Service Categories</th>
                                    <th>Contract ID</th>
                                    <th>Total Amount</th>
                                    <th>Spent Amount</th>
                                    <th>Remaining Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
        `;

        results.forEach(row => {
            html += `
                                <tr>
                                    <td>${row.ContactName}</td>
                                    <td>${row.ServiceCategories}</td>
                                    <td>${row.ContractID}</td>
                                    <td>${row.TotalAmount}</td>
                                    <td>${row.SpentAmount}</td>
                                    <td>${row.RemainingAmount}</td>
                                    <td>${row.ExpenditureStatus}</td>
                                    <td><button class="btn btn-warning" onclick="location.href='/edit-budget/${row.VendorID}'">Edit</button></td>
                                </tr>
            `;
        });

        html += `
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center">
                        <button class="btn btn-danger" onclick="location.href='/logout'">Logout</button>
                    </div>
                </div>
                <script>
                    function toggleTable() {
                        const table = document.getElementById('budgetTable');
                        table.style.display = table.style.display === 'none' ? 'block' : 'none';
                    }
                </script>
                <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            </body>
            </html>
        `;

        res.send(html);
    });
});
app.get('/edit-budget/:VendorID', (req, res) => {
    const vendorId = req.params.VendorID;

    const query = 'SELECT * FROM Budget WHERE VendorID = ?';
    db.query(query, [vendorId], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error fetching budget data:', err);
            return res.status(500).send('Error fetching budget data.');
        }

        const budget = results[0];

        // Create the form to edit budget details
        res.send(`
            <h1>Edit Budget for Vendor ${vendorId}</h1>
            <form action="/update-budget/${vendorId}" method="POST">
                <label for="TotalAmount">Total Amount:</label>
                <input type="number" id="TotalAmount" name="TotalAmount" value="${budget.TotalAmount}" required><br><br>

                <label for="SpentAmount">Spent Amount:</label>
                <input type="number" id="SpentAmount" name="SpentAmount" value="${budget.SpentAmount}" required><br><br>

                <label for="RemainingAmount">Remaining Amount:</label>
                <input type="number" id="RemainingAmount" name="RemainingAmount" value="${budget.RemainingAmount}" required><br><br>

                <label for="ExpenditureStatus">Status:</label>
                <input type="text" id="ExpenditureStatus" name="ExpenditureStatus" value="${budget.ExpenditureStatus}" required><br><br>

                <label for="ActionMessage">Action Message:</label>
                <input type="text" id="ActionMessage" name="ActionMessage" placeholder="Enter a custom message" required><br><br>

                <button type="submit">Update Budget</button>
            </form>
            <button onclick="location.href='/Budget-Manager'">Return to Dashboard</button>
        `);
    });
});
// Route to handle budget updates and log the action
app.post('/update-budget/:VendorID', (req, res) => {
    const vendorId = req.params.VendorID;
    const { TotalAmount, SpentAmount, RemainingAmount, ExpenditureStatus, ActionMessage } = req.body;

    // SQL query to join Vendor, User, and AuditLog tables
    const joinQuery = `
        SELECT v.VendorID, v.ContactName, u.UserID, a.ActionType, a.Timestamp
        FROM Vendor v
        JOIN User u ON v.UserID = u.UserID
        LEFT JOIN AuditLog a ON u.UserID = a.UserID
        WHERE v.VendorID = ?
    `;

    db.query(joinQuery, [vendorId], (err, joinResults) => {
        if (err || joinResults.length === 0) {
            console.error('Error fetching joined data:', err);
            return res.status(500).send('Error fetching vendor-user-audit data.');
        }

        // Extract the UserID for the audit log insertion
        const userId = joinResults[0].UserID;

        // Update the Budget table
        const updateBudgetQuery = `
            UPDATE Budget
            SET TotalAmount = ?, SpentAmount = ?, RemainingAmount = ?, ExpenditureStatus = ?
            WHERE VendorID = ?
        `;

        db.query(updateBudgetQuery, [TotalAmount, SpentAmount, RemainingAmount, ExpenditureStatus, vendorId], (err, updateResult) => {
            if (err) {
                console.error('Error updating budget:', err);
                return res.status(500).send('Error updating budget.');
            }

            // Insert into the AuditLog table
            const auditLogQuery = `
                INSERT INTO AuditLog (UserID, ActionType)
                VALUES (?, ?)
            `;
            const actionType = ActionMessage || 'Updated Budget'; // Default message if none is provided

            db.query(auditLogQuery, [userId, actionType], (err, auditResult) => {
                if (err) {
                    console.error('Error inserting into AuditLog:', err);
                    return res.status(500).send('Error logging action.');
                }

                // Redirect back to the dashboard after successful update and log
                res.redirect('/Budget-Manager');
            });
        });
    });
});

app.get('/department-head-dashboard', (req, res) => {
    res.send(`
       <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Head Dashboard</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        :root {
            --bg-primary: #121212;
            --bg-secondary: #1e1e1e;
            --accent-primary: #6b46c1;
            --accent-secondary: #9f7aea;
            --text-primary: #e2e8f0;
            --text-secondary: #718096;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Manrope', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, var(--bg-primary) 0%, #1a202c 100%);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .dashboard-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background-color: var(--bg-secondary);
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(106, 70, 193, 0.1);
            box-shadow: 10px 0 15px -5px rgba(0,0,0,0.1);
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            color: var(--accent-primary);
            font-weight: 800;
            font-size: 1.5rem;
        }

        .sidebar-menu {
            flex-grow: 1;
        }

        .sidebar-btn {
            display: flex;
            align-items: center;
            width: 100%;
            padding: 12px 20px;
            margin-bottom: 10px;
            border: none;
            border-radius: 10px;
            background-color: transparent;
            color: var(--text-secondary);
            font-weight: 600;
            text-align: left;
            transition: all 0.3s ease;
        }

        .sidebar-btn:hover, .sidebar-btn.active {
            background-color: rgba(106, 70, 193, 0.1);
            color: var(--accent-primary);
            transform: translateX(10px);
        }

        .sidebar-btn svg {
            margin-right: 12px;
            stroke: var(--text-secondary);
            transition: stroke 0.3s ease;
        }

        .sidebar-btn:hover svg, .sidebar-btn.active svg {
            stroke: var(--accent-primary);
        }

        .main-content {
            flex-grow: 1;
            padding: 40px;
            background: linear-gradient(to right bottom, rgba(26,32,44,0.9), rgba(18,24,34,0.9));
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .dashboard-card {
            background-color: var(--bg-secondary);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(106, 70, 193, 0.1);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .dashboard-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }

        .card-title {
            color: var(--accent-secondary);
            font-weight: 700;
            margin-bottom: 15px;
        }

        .action-btn {
            background: linear-gradient(to right, var(--accent-primary), var(--accent-secondary));
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 15px;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(106, 70, 193, 0.3);
        }

        @media (max-width: 768px) {
            .dashboard-wrapper {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
            }
            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-wrapper">
        <div class="sidebar">
            <div class="sidebar-logo">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
                Dashboard
            </div>

            <div class="sidebar-menu">
                <button class="sidebar-btn" onclick="location.href='/add-vendor-formforhead'">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="8.5" cy="7" r="4"></circle>
                        <line x1="20" y1="8" x2="20" y2="14"></line>
                        <line x1="23" y1="11" x2="17" y2="11"></line>
                    </svg>
                    Add Vendor
                </button>
                <button class="sidebar-btn" onclick="location.href='/vendor-list'">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="7" height="7"></rect>
                        <rect x="14" y="3" width="7" height="7"></rect>
                        <rect x="14" y="14" width="7" height="7"></rect>
                        <rect x="3" y="14" width="7" height="7"></rect>
                    </svg>
                    View Vendors
                </button>
                <button class="sidebar-btn" onclick="location.href='/submitted-vendor-list'">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    Submitted Orders
                </button>
                <button class="sidebar-btn" onclick="location.href='/vendor-list-for-task'">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                        <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                    </svg>
                    Add Task
                </button>
                <div class="sidebar-btn" role="button" data-bs-toggle="dropdown">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                    Performance
                    <div class="dropdown-menu">
                        <button class="action-btn" onclick="location.href='/vendor-listforperformance'">Edit Performance</button>
                        <button class="action-btn" onclick="location.href='/vendor-listforperformance-without-data'">Add Performance</button>
                       
                    </div>
                </div>
            </div>

            <button class="sidebar-btn logout-btn" onclick="location.href='/logout'" style="margin-top: auto; color: #ef4444;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                Logout
            </button>
        </div>

        <main class="main-content">
            <div class="dashboard-header">
                <h1 style="font-size: 2rem; font-weight: 700; color: var(--accent-secondary);">Department Head Dashboard</h1>
            </div>

            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3 class="card-title">Vendor Management</h3>
                    <p>Manage and track your vendors efficiently.</p>
                    <button class="action-btn" onclick="location.href='/vendor-list'">View Vendors</button>
                </div>
                <div class="dashboard-card">
                    <h3 class="card-title">Task Tracking</h3>
                    <p>Assign and monitor tasks across your vendor network.</p>
                    <button class="action-btn" onclick="location.href='/vendor-list-for-task'">Add Task</button>
                </div>
                <div class="dashboard-card">
                    <h3 class="card-title">Performance Insights</h3>
                    <p>Evaluate and manage vendor performance.</p>
                    <button class="action-btn" onclick="location.href='/vendor-listforperformance'">View Performance</button>
                </div>
            </div>
        </main>
    </div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `);
});
app.get('/vendor-listforperformance', (req, res) => {
    const query = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            d.DepartmentID,
            u.DepartmentName,
            u.Name AS ContactName,
            c.ContractID  -- Fetch ContractID from Contract table
        FROM 
            Vendor v
        JOIN 
            User u ON v.UserID = u.UserID
        JOIN 
            Department d ON u.DepartmentName = d.DepartmentName
        LEFT JOIN 
            Contract c ON v.VendorID = c.VendorID;  -- Join Contract table to get ContractID
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching vendor data:', err);
            return res.status(500).send('Error fetching vendor data');
        }

        let tableRows = results
            .map(
                (row) => `
                <tr>
                    <td>${row.VendorID}</td>
                    <td>${row.OrganizationName}</td>
                    <td>${row.DepartmentName}</td>
                    <td>${row.ContactName}</td>
                    <td>${row.ContractID || 'No Contract'}</td>
                   
                    <td>
                        <button onclick="location.href='/edit-vendor-performance/${row.VendorID}'">Edit Performance</button>
                    </td>
                </tr>`
            )
            .join('');

        res.send(`
            <h1>Vendor List</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Vendor ID</th>
                        <th>Organization Name</th>
                        <th>Department Name</th>
                        <th>Contact Name</th>
                        <th>Contract ID</th>
                    
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button onclick="location.href='/department-head-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.get('/edit-vendor-performance/:vendorID', (req, res) => {
    const vendorID = req.params.vendorID;

    // Fetch the vendor's current performance data (if exists)
    const query = `
        SELECT * FROM VendorPerformance WHERE VendorID = ?;
    `;
    db.query(query, [vendorID], (err, results) => {
        if (err) {
            console.error('Error fetching vendor performance:', err);
            return res.status(500).send('Error fetching vendor performance');
        }

        // If no existing performance data, create a blank form
        const performance = results.length > 0 ? results[0] : {};

        res.send(`
            <h1>Edit Performance for Vendor ${vendorID}</h1>
            <form action="/update-vendor-performance" method="POST">
                <input type="hidden" name="vendorID" value="${vendorID}">
                <label for="performancePeriod">Performance Period:</label>
                <input type="text" id="performancePeriod" name="performancePeriod" value="${performance.PerformancePeriod || ''}" required><br><br>
                
                <label for="deliveryTimeliness">Delivery Timeliness:</label>
                <input type="number" id="deliveryTimeliness" name="deliveryTimeliness" value="${performance.DeliveryTimeliness || ''}" step="0.01" min="0"  required><br><br>
                
                <label for="serviceQuality">Service Quality:</label>
                <input type="number" id="serviceQuality" name="serviceQuality" value="${performance.ServiceQuality || ''}" step="0.01" min="0"  required><br><br>
                
                <label for="pricing">Pricing:</label>
                <input type="number" id="pricing" name="pricing" value="${performance.Pricing || ''}" step="0.01" min="0" required><br><br>
                
                <label for="complianceAdherence">Compliance Adherence:</label>
                <input type="number" id="complianceAdherence" name="complianceAdherence" value="${performance.ComplianceAdherence || ''}" step="0.01" min="0"  required><br><br>
                
                <label for="performanceRating">Performance Rating:</label>
                <input type="number" id="performanceRating" name="performanceRating" value="${performance.PerformanceRating || ''}" step="0.01" min="0"  required><br><br>
                
                <label for="remarks">Remarks:</label>
                <textarea id="remarks" name="remarks">${performance.Remarks || ''}</textarea><br><br>
                
                <button type="submit">Update Performance</button>
            </form>
            <button onclick="location.href='/vendor-listforperformance'">Back to Vendor List</button>
        `);
    });
});
app.post('/update-vendor-performance', (req, res) => {
    const { vendorID, performancePeriod, deliveryTimeliness, serviceQuality, pricing, complianceAdherence, performanceRating, remarks } = req.body;

    const updateQuery = `
        INSERT INTO VendorPerformance (VendorID, PerformancePeriod, DeliveryTimeliness, ServiceQuality, Pricing, ComplianceAdherence, PerformanceRating, Remarks)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            PerformancePeriod = VALUES(PerformancePeriod),
            DeliveryTimeliness = VALUES(DeliveryTimeliness),
            ServiceQuality = VALUES(ServiceQuality),
            Pricing = VALUES(Pricing),
            ComplianceAdherence = VALUES(ComplianceAdherence),
            PerformanceRating = VALUES(PerformanceRating),
            Remarks = VALUES(Remarks);
    `;

    db.query(updateQuery, [vendorID, performancePeriod, deliveryTimeliness, serviceQuality, pricing, complianceAdherence, performanceRating, remarks], (err, results) => {
        if (err) {
            console.error('Error updating vendor performance:', err);
            return res.status(500).send('Error updating vendor performance');
        }

        res.send(`
            <h2>Vendor performance updated successfully.</h2>
            <button onclick="location.href='/vendor-listforperformance'">Return to Vendor List</button>
        `);
    });
});

app.get('/vendor-listforperformance-without-data', (req, res) => {
    const query = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            d.DepartmentID,
            u.DepartmentName,
            u.Name AS ContactName
        FROM 
            Vendor v
        JOIN 
            User u ON v.UserID = u.UserID
        JOIN 
            Department d ON u.DepartmentName = d.DepartmentName
        LEFT JOIN 
            VendorPerformance vp ON v.VendorID = vp.VendorID
        WHERE 
            vp.VendorID IS NULL;  -- Only vendors without performance data
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching vendor data:', err);
            return res.status(500).send('Error fetching vendor data');
        }

        let tableRows = results
            .map(
                (row) => `
                <tr>
                    <td>${row.VendorID}</td>
                    <td>${row.OrganizationName}</td>
                    <td>${row.DepartmentName}</td>
                    <td>${row.ContactName}</td>
                    <td>
                        <button onclick="location.href='/add-vendor-performance/${row.VendorID}'">Add Performance</button>
                    </td>
                </tr>`
            )
            .join('');

        res.send(`
            <h1>Vendor List (Without Performance Data)</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Vendor ID</th>
                        <th>Organization Name</th>
                        <th>Department Name</th>
                        <th>Contact Name</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button onclick="location.href='/department-head-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.get('/add-vendor-performance/:vendorID', (req, res) => {
    const vendorID = req.params.vendorID;

    // Fetch the vendor's contract and performance data (if exists)
    const query = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            c.ContractID,
            vp.VendorID AS PerformanceVendorID
        FROM 
            Vendor v
        LEFT JOIN 
            Contract c ON v.VendorID = c.VendorID
        LEFT JOIN 
            VendorPerformance vp ON v.VendorID = vp.VendorID
        WHERE 
            v.VendorID = ? AND c.ContractID IS NOT NULL AND vp.VendorID IS NULL;
    `;

    db.query(query, [vendorID], (err, results) => {
        if (err) {
            console.error('Error fetching vendor performance:', err);
            return res.status(500).send('Error fetching vendor performance');
        }

        if (results.length === 0) {
            return res.status(404).send('Vendor does not have a contract or already has performance data');
        }

        // No existing performance data, so show the form to insert performance data
        res.send(`
            <h1>Insert Performance for Vendor ${vendorID}</h1>
            <form action="/addd-vendor-performance" method="POST">
                <input type="hidden" name="vendorID" value="${vendorID}">
                <label for="performancePeriod">Performance Period:</label>
                <input type="text" id="performancePeriod" name="performancePeriod" required><br><br>
                
                <label for="deliveryTimeliness">Delivery Timeliness:</label>
                <input type="number" id="deliveryTimeliness" name="deliveryTimeliness" step="0.01" min="0" required><br><br>
                
                <label for="serviceQuality">Service Quality:</label>
                <input type="number" id="serviceQuality" name="serviceQuality" step="0.01" min="0" required><br><br>
                
                <label for="pricing">Pricing:</label>
                <input type="number" id="pricing" name="pricing" step="0.01" min="0" required><br><br>
                
                <label for="complianceAdherence">Compliance Adherence:</label>
                <input type="number" id="complianceAdherence" name="complianceAdherence" step="0.01" min="0" required><br><br>
                
                <label for="performanceRating">Performance Rating:</label>
                <input type="number" id="performanceRating" name="performanceRating" step="0.01" min="0" required><br><br>
                
                <label for="remarks">Remarks:</label>
                <textarea id="remarks" name="remarks"></textarea><br><br>
                
                <button type="submit">Insert Performance</button>
            </form>
            <button onclick="location.href='/vendor-listforperformance-without-data'">Back to Vendor List</button>
        `);
    });
});

app.post('/addd-vendor-performance', (req, res) => {
    const { vendorID, performancePeriod, deliveryTimeliness, serviceQuality, pricing, complianceAdherence, performanceRating, remarks } = req.body;

    const updateQuery = `
        CALL AddVendorPerformance(?, ?, ?, ?, ?, ?, ?, ?);
    `;

    db.query(updateQuery, [vendorID, performancePeriod, deliveryTimeliness, serviceQuality, pricing, complianceAdherence, performanceRating, remarks], (err, results) => {
        if (err) {
            console.error('Error inserting vendor performance:', err);
            return res.status(500).send('Error inserting vendor performance');
        }

        res.send(`
            <h2>Vendor performance inserted successfully.</h2>
            <button onclick="location.href='/vendor-listforperformance-without-data'">Return to Vendor List</button>
        `);
    });
});


app.get('/vendor-list-for-task', (req, res) => {
 
        const query = `
            SELECT 
                v.VendorID,
                v.OrganizationName,
                d.DepartmentID,
                u.DepartmentName,
                u.Name AS ContactName,
                c.ContractID
            FROM 
                Vendor v
            JOIN 
                User u ON v.UserID = u.UserID
            JOIN 
                Department d ON u.DepartmentName = d.DepartmentName
            LEFT JOIN 
                Contract c ON v.VendorID = c.VendorID;
        `;
    
        db.query(query, (err, results) => {
            if (err) {
                console.error('Error fetching vendor data:', err);
                return res.status(500).send('Error fetching vendor data');
            }
    
            let tableRows = results
                .map(
                    (row) => `
                    <tr>
                        <td>${row.VendorID}</td>
                        <td>${row.OrganizationName}</td>
                        <td>${row.DepartmentName}</td>
                        <td>${row.ContactName}</td>
                        <td>${row.ContractID || 'No Contract'}</td>
                    
                        <td>
                            <a href="/assign-task-form?vendorID=${row.VendorID}">Assign Task</a> <!-- Link to the Task form -->
                        </td>
                    </tr>`
                )
                .join('');
    
            res.send(`
                <h1>Vendor List</h1>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Vendor ID</th>
                            <th>Organization Name</th>
                            <th>Department Name</th>
                            <th>Contact Name</th>
                            <th>Contract ID</th>

                            <th>Assign Task</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${tableRows}
                    </tbody>
                </table>
                <button onclick="location.href='/department-head-dashboard'">Back to Dashboard</button>
            `);
        });
    });
    
    app.get('/assign-task-form', (req, res) => {
        const vendorID = req.query.vendorID;  // Get the VendorID from query parameters
    
        // Render the task form for that specific vendor
        res.send(`
            <h1>Assign Task to Vendor</h1>
            <form action="/assign-task" method="POST">
                <input type="hidden" name="vendorID" value="${vendorID}">
                
                <label for="taskDescription">Task Description:</label>
                <input type="text" id="taskDescription" name="taskDescription" required><br><br>
                
                <label for="dueDate">Due Date:</label>
                <input type="date" id="dueDate" name="dueDate" required><br><br>
                
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                </select><br><br>
                
                <button type="submit">Assign Task</button>
            </form>
            <button onclick="location.href='/vendor-list'">Back to Vendor List</button>
        `);
    });
    
    app.post('/assign-task', (req, res) => {
        const { vendorID, taskDescription, dueDate, status } = req.body;
    
        // Insert the task into the Task table
        const taskQuery = `
            INSERT INTO Task (AssignedTo, Description, DueDate, Status)
            VALUES (?, ?, ?, ?);
        `;
        
        db.query(taskQuery, [vendorID, taskDescription, dueDate, status], (err, taskResults) => {
            if (err) {
                console.error('Error adding task:', err);
                return res.status(500).send('Error adding task');
            }
    
            const taskID = taskResults.insertId;
    
            // Optionally, you can insert a notification for the vendor
            const notificationMessage = `New task assigned to you. Task ID: ${taskID}, Description: ${taskDescription}, Due Date: ${dueDate}, Status: ${status}`;
            const notificationQuery = `
                INSERT INTO Notification (UserID, Message) 
                VALUES (?, ?);
            `;
            
            db.query(notificationQuery, [vendorID, notificationMessage], (err) => {
                if (err) {
                    console.error('Error adding notification:', err);
                    return res.status(500).send('Error adding notification');
                }
    
                // Redirect to a confirmation page or back to vendor list
                res.send(`
                    <h2>Task successfully assigned to vendor.</h2>
                    <button onclick="location.href='/vendor-list'">Return to Vendor List</button>
                `);
            });
        });
    });
    app.get('/vendor-purchase-orders/:vendorID', (req, res) => {
    const vendorID = req.params.vendorID;  // Get the vendor ID from the URL parameter

    const query = `
        SELECT 
            po.PurchaseOrderID,
            po.ItemDetails,
            po.Quantity,
            po.ServicesOrdered,
            po.TotalCost,
            po.Status,
            po.BudgetID
        FROM 
            PurchaseOrder po
        JOIN 
            Vendor v ON po.VendorID = v.VendorID
        WHERE 
            po.VendorID = ? AND po.Status = 'Submitted';
    `;

    db.query(query, [vendorID], (err, results) => {
        if (err) {
            console.error('Error fetching purchase order details:', err);
            return res.status(500).send('Error fetching purchase order details');
        }

        // If no purchase orders are found for this vendor
        if (results.length === 0) {
            return res.send('<h2>No submitted purchase orders found for this vendor.</h2>');
        }

        let tableRows = results
            .map(
                (row) => `
                <tr>
                    <td>${row.PurchaseOrderID}</td>
                    <td>${row.ItemDetails}</td>
                    <td>${row.Quantity}</td>
                    <td>${row.ServicesOrdered}</td>
                    <td>${row.TotalCost}</td>
                    <td>${row.Status}</td>
                    <td>${row.BudgetID}</td>
                </tr>`
            )
            .join('');

        res.send(`
            <h1>Purchase Orders for Vendor ${vendorID}</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Purchase Order ID</th>
                        <th>Item Details</th>
                        <th>Quantity</th>
                        <th>Services Ordered</th>
                        <th>Total Cost</th>
                        <th>Status</th>
                        <th>Budget ID</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button onclick="location.href='/submitted-vendor-list'">Back to Submitted Vendor List</button>
        `);
    });
});
app.get('/submitted-vendor-list', (req, res) => {
    const query = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            d.DepartmentID,
            u.DepartmentName,
            u.Name AS ContactName
        FROM 
            Vendor v
        JOIN 
            User u ON v.UserID = u.UserID
        JOIN 
            Department d ON u.DepartmentName = d.DepartmentName
        JOIN 
            PurchaseOrder po ON v.VendorID = po.VendorID
        WHERE 
            po.Status = 'Submitted';
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching vendor data with submitted orders:', err);
            return res.status(500).send('Error fetching vendor data');
        }

        let tableRows = results
            .map(
                (row) => `
                <tr>
                    <td>${row.VendorID}</td>
                    <td>${row.OrganizationName}</td>
                    <td>${row.DepartmentName}</td>
                    <td>${row.ContactName}</td>
                    
                    <td>
                        <button onclick="location.href='/vendor-purchase-orders/${row.VendorID}'">View Purchase Orders</button>
                    </td>
                </tr>`
            )
            .join('');

        res.send(`
            <h1>Vendors with Submitted Purchase Orders</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Vendor ID</th>
                        <th>Organization Name</th>
                        <th>Department Name</th>
                        <th>Contact Name</th>
                        <th>View Orders</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button onclick="location.href='/department-head-dashboard'">Back to Dashboard</button>
        `);
    });
});


app.get('/vendor-list', (req, res) => {
    const query = `
        SELECT 
            v.VendorID,
            v.OrganizationName,
            d.DepartmentID,
            u.DepartmentName,
            u.Name AS ContactName,
            c.ContractID  -- Fetch ContractID from Contract table
        FROM 
            Vendor v
        JOIN 
            User u ON v.UserID = u.UserID
        JOIN 
            Department d ON u.DepartmentName = d.DepartmentName
        LEFT JOIN 
            Contract c ON v.VendorID = c.VendorID;  -- Join Contract table to get ContractID
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching vendor data:', err);
            return res.status(500).send('Error fetching vendor data');
        }

        let tableRows = results
            .map(
                (row) => `
                <tr>
                    <td>${row.VendorID}</td>
                    <td>${row.OrganizationName}</td>
                    <td>${row.DepartmentName}</td>
                    <td>${row.ContactName}</td>
                    <td>${row.ContractID || 'No Contract'}</td>  <!-- Display ContractID -->
                    <td>
                        <form action="/add-purchase-order-form" method="GET">
                            <input type="hidden" name="vendorID" value="${row.VendorID}">
                            <input type="hidden" name="departmentID" value="${row.DepartmentID}">
                            <input type="hidden" name="contractID" value="${row.ContractID || ''}">  <!-- Pass ContractID -->
                            <button type="submit">Insert Purchase Order</button>
                        </form>
                    </td>
                </tr>`
            )
            .join('');

        res.send(`
            <h1>Vendor List</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Vendor ID</th>
                        <th>Organization Name</th>
                        <th>Department Name</th>
                        <th>Contact Name</th>
                        <th>Contract ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button onclick="location.href='/department-head-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.get('/add-purchase-order-form', (req, res) => {
    const { vendorID, departmentID, contractID } = req.query;

    // Fetch the latest Budget ID from the database (assuming it is an auto-incremented ID)
    const getLatestBudgetIDQuery = 'SELECT MAX(BudgetID) AS latestBudgetID FROM Budget';

    db.query(getLatestBudgetIDQuery, (err, results) => {
        if (err) {
            console.error('Error fetching latest Budget ID:', err);
            return res.status(500).send('Error fetching Budget ID');
        }

        const latestBudgetID = results[0].latestBudgetID + 1 || 1;  // Increment the latest ID or start from 1 if no records

        res.send(`
            <form action="/submit-purchase-order-and-budget" method="POST">
                <input type="hidden" name="vendorID" value="${vendorID}">
                <input type="hidden" name="departmentID" value="${departmentID}">
                <input type="hidden" name="contractID" value="${contractID}">  <!-- Pass ContractID -->
                
                <h2>Purchase Order</h2>
                Item Details: <textarea name="itemDetails" required></textarea><br>
                Quantity: <input type="number" name="quantity" required><br>
                Services Ordered: <textarea name="servicesOrdered"></textarea><br>
                Total Cost: <input type="number" name="totalCost" step="0.01" required><br>
                Budget ID: <input type="text" name="budgetID" value="${latestBudgetID}" readonly><br>
                Status: 
                <select name="status" required>
                    <option value="Submitted">Submitted</option>
                    <option value="Not Submitted">Not Submitted</option>
                </select><br>
                
                <h2>Budget Details</h2>
                Expense Category: <input type="text" name="expenseCategory" required><br>
                Total Amount: <input type="number" name="totalAmount" step="0.01" required><br>
                Spent Amount: <input type="number" name="spentAmount" step="0.01" required><br>
                Remaining Amount: <input type="number" name="remainingAmount" step="0.01" required><br>
                Date: <input type="date" name="date" required><br>
                Expenditure Status: 
                <select name="expenditureStatus" required>
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Paid">Paid</option>
                </select><br>
                Alert Threshold: <input type="number" name="alertThreshold" step="0.01" required><br>
                
                <button type="submit">Submit</button>
            </form>
        `);
    });
});

app.post('/submit-purchase-order-and-budget', (req, res) => {
    const {
        vendorID,
        departmentID,
        itemDetails,
        quantity,
        servicesOrdered,
        totalCost,
        budgetID,  // This is the BudgetID you want to insert into the PurchaseOrder
        status,
        expenseCategory,
        totalAmount,
        spentAmount,
        remainingAmount,
        date,
        expenditureStatus,
        alertThreshold,
        contractID  // Add ContractID to the request body
    } = req.body;

    // Insert into Budget first if the BudgetID doesn't exist
    const budgetQuery = `
        INSERT INTO Budget 
        (VendorID, ContractID, DepartmentID, ExpenseCategory, TotalAmount, SpentAmount, RemainingAmount, Date, ExpenditureStatus, AlertThreshold) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);  -- Insert ContractID as well
    `;

    // Insert into PurchaseOrder after inserting the Budget
    const purchaseOrderQuery = `
        INSERT INTO PurchaseOrder 
        (DepartmentID, VendorID, ItemDetails, Quantity, ServicesOrdered, TotalCost, BudgetID, Status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);  -- Insert ContractID in PurchaseOrder as well
    `;

    db.beginTransaction((err) => {
        if (err) {
            console.error('Error starting transaction:', err);
            return res.status(500).send('Error processing request');
        }

        // If BudgetID doesn't exist, insert a new record into Budget
        db.query(
            budgetQuery,
            [vendorID,contractID  , departmentID, expenseCategory, totalAmount, spentAmount, remainingAmount, date, expenditureStatus, alertThreshold, contractID],
            (err, result) => {
                if (err) {
                    return db.rollback(() => {
                        console.error('Error inserting budget:', err);
                        return res.status(500).send('Error inserting budget');
                    });
                }

                // Get the newly generated BudgetID if we inserted a new record
                const newBudgetID = result.insertId || budgetID;

                // Now insert into PurchaseOrder using the new BudgetID
                db.query(
                    purchaseOrderQuery,
                    [departmentID, vendorID, itemDetails, quantity, servicesOrdered, totalCost, newBudgetID, status, contractID],
                    (err) => {
                        if (err) {
                            return db.rollback(() => {
                                console.error('Error inserting purchase order:', err);
                                return res.status(500).send('Error inserting purchase order');
                            });
                        }

                        db.commit((err) => {
                            if (err) {
                                return db.rollback(() => {
                                    console.error('Error committing transaction:', err);
                                    return res.status(500).send('Error committing transaction');
                                });
                            }

                            res.redirect('/vendor-list');
                        });
                    }
                );
            }
        );
    });
});

app.get('/add-vendor-formforhead', (req, res) => {
    res.send(`
        <form action="/submit2" method="POST">
            <h2>Vendor Information</h2>
            Organization Name: <input type="text" name="organizationName" required><br>
            Service Categories: <input type="text" name="serviceCategories"><br>
            Contact Name: <input type="text" name="contactName"><br>
            Contact Email: <input type="email" name="contactEmail" required><br>
            Contact Phone: <input type="text" name="contactPhone" required><br>
            Contact Address: <input type="text" name="contactAddress"><br>
            CNIC Number: <input type="text" name="cnicNumber" required><br>
            
            <h2>Compliance Certification</h2>
            Certification Number: <input type="text" name="certificationNumber" required><br>
            Certificate Name: <input type="text" name="certificateName" required><br>
            Issued By Company: <input type="text" name="issuedByCompany" required><br>
            Attested By Person: <input type="text" name="attestedByPerson" required><br>
            Issue Date: <input type="date" name="issueDate" required><br>
            Expiry Date: <input type="date" name="expiryDate" required><br>
            Status: 
            <select name="status" required>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Under Review">Under Review</option>
            </select><br>
            <button type="submit">Submit</button>
        </form>
    `);
});


app.post('/submit2', (req, res) => {
    const {
        organizationName,
        serviceCategories,
        contactName,
        contactEmail,
        contactPhone,
        contactAddress,
        cnicNumber,
        certificationNumber,
        certificateName,
        issuedByCompany,
        attestedByPerson,
        issueDate,
        expiryDate,
        status,
    } = req.body;

    // Insert Vendor
    const vendorQuery = `
        INSERT INTO Vendor 
        (OrganizationName, ServiceCategories, ContactName, ContactEmail, ContactPhone, ContactAddress, CNICNumber) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(
        vendorQuery,
        [organizationName, serviceCategories, contactName, contactEmail, contactPhone, contactAddress, cnicNumber],
        (err, vendorResult) => {
            if (err) {
                console.error('Error inserting vendor:', err);
                return res.status(500).send('Error inserting vendor.');
            }

            const vendorID = vendorResult.insertId;

            // Insert Compliance Certification
            const certificationQuery = `
                INSERT INTO ComplianceCertifications 
                (CertificationNumber, CertificateName, IssuedByCompany, AttestedByPerson, IssueDate, ExpiryDate, Status, VendorID) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;

            db.query(
                certificationQuery,
                [certificationNumber, certificateName, issuedByCompany, attestedByPerson, issueDate, expiryDate, status, vendorID],
                (err) => {
                    if (err) {
                        console.error('Error inserting certification:', err);
                        return res.status(500).send('Error inserting certification.');
                    }

                    // Successful insertion
                    res.redirect('/department-head-dashboard'); // Redirect on success
                }
            );
        }
    );
});
app.get('/add-purchase-order', (req, res) => {
    res.send(`
        <h1>Add Purchase Order</h1>
        <form method="POST" action="/add-purchase-order">
            <label for="departmentID">Department ID:</label>
            <input type="number" id="departmentID" name="departmentID" required />
            <label for="vendorID">Vendor ID:</label>
            <input type="number" id="vendorID" name="vendorID" required />
            <label for="itemDetails">Item Details:</label>
            <textarea id="itemDetails" name="itemDetails" required></textarea>
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" required />
            <label for="servicesOrdered">Services Ordered:</label>
            <textarea id="servicesOrdered" name="servicesOrdered"></textarea>
            <label for="totalCost">Total Cost:</label>
            <input type="number" step="0.01" id="totalCost" name="totalCost" required />
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Submitted">Submitted</option>
                <option value="Not Submitted">Not Submitted</option>
            </select>
            <label for="budgetID">Budget ID:</label>
            <input type="number" id="budgetID" name="budgetID" />
            <button type="submit">Add Purchase Order</button>
        </form>
    `);
});

app.post('/add-purchase-order', (req, res) => {
    const { departmentID, vendorID, itemDetails, quantity, servicesOrdered, totalCost, status, budgetID } = req.body;
    const query = `
        INSERT INTO PurchaseOrder 
        (DepartmentID, VendorID, ItemDetails, Quantity, ServicesOrdered, TotalCost, Status, BudgetID) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [departmentID, vendorID, itemDetails, quantity, servicesOrdered, totalCost, status, budgetID], (err) => {
        if (err) {
            console.error('Error adding purchase order:', err);
            return res.status(500).send('<h1>Failed to add purchase order. Please try again.</h1>');
        }
        res.send('<h1>Purchase Order added successfully!</h1><a href="/department-head-dashboard">Back to Dashboard</a>');
    });
});




// Signup Page
app.get('/signup', (req, res) => {
    res.send(`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Management System - Signup</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #50c878;
            --background-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--background-gradient);
            overflow: hidden;
        }

        .signup-container {
            display: flex;
            height: 100vh;
            perspective: 1000px;
        }

        .signup-wrapper {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            display: flex;
            box-shadow: 0 30px 60px rgba(0,0,0,0.2);
            border-radius: 20px;
            overflow: hidden;
            background: white;
            transform: rotateY(-10deg);
            transition: all 0.6s ease;
        }

        .signup-wrapper:hover {
            transform: rotateY(0deg);
        }

        .signup-visual {
            flex: 1;
            background: url('data:image/png;base64,/* PASTE BASE64 IMAGE HERE */') no-repeat center center;
            background-size: cover;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--primary-color);
        }

        .signup-visual::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(74, 144, 226, 0.8);
            mix-blend-mode: multiply;
        }

        .signup-visual-content {
            position: relative;
            z-index: 2;
            color: white;
            text-align: center;
            padding: 30px;
        }

        .signup-form {
            flex: 1;
            padding: 50px;
            background: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .signup-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .signup-header h2 {
            color: var(--primary-color);
            font-weight: 800;
            margin-bottom: 10px;
        }

        .form-control, .form-select {
            border: none;
            border-bottom: 2px solid #e0e0e0;
            border-radius: 0;
            padding: 10px 0;
            transition: border-color 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            box-shadow: none;
            border-color: var(--primary-color);
        }

        .btn-signup {
            background: var(--background-gradient);
            border: none;
            padding: 12px;
            border-radius: 30px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: transform 0.3s ease;
        }

        .btn-signup:hover {
            transform: scale(1.05);
        }

        .signup-footer {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
        }

        @media (max-width: 768px) {
            .signup-container {
                perspective: none;
            }

            .signup-wrapper {
                flex-direction: column;
                transform: none;
            }

            .signup-visual, .signup-form {
                flex: none;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <div class="signup-wrapper">
            <div class="signup-visual">
                <div class="signup-visual-content">
                    <h3>Welcome to Vendor Management</h3>
                    <p>Streamline your vendor processes with cutting-edge technology</p>
                </div>
            </div>
            <div class="signup-form">
                <div class="signup-header">
                    <h2>Create Account</h2>
                    <p class="text-muted">Join our vendor ecosystem</p>
                </div>
                <form action="/signup" method="POST">
                    <div class="row g-3">
                        <div class="col-12">
                            <input type="text" class="form-control" name="Name" placeholder="Full Name" required>
                        </div>
                        <div class="col-12">
                            <input type="email" class="form-control" name="Email" placeholder="Email Address" required>
                        </div>
                        <div class="col-12">
                            <input type="text" class="form-control" name="DepartmentName" placeholder="Department Name" required>
                        </div>
                        <div class="col-12">
                            <select class="form-select" name="Role" required>
                                <option value="" disabled selected>Select Your Role</option>
                                <option value="Department Head">Department Head</option>
                                <option value="Procurement Manager">Procurement Manager</option>
                                <option value="Vendor">Vendor</option>
                                <option value="Budget Manager">Budget Manager</option>
                                <option value="Finance Team">Finance Team</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <input type="password" class="form-control" name="Password" placeholder="Create Password" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-signup w-100">Sign Up</button>
                        </div>
                    </div>
                </form>
                <div class="signup-footer">
                    Already have an account? <a href="/login" class="text-primary">Login</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

    `);
});
app.get('/logout', (req, res) => {
    if (req.session) {
        req.session.destroy((err) => {
            if (err) {
                console.error('Error during logout:', err);
                return res.status(500).send('<h1>Logout failed. Please try again.</h1>');
            }
            res.redirect('/');
        });
    } else {
        res.redirect('/');
    }
});
app.post('/signup', (req, res) => {
    const { Name, Email, DepartmentName, Role, Password } = req.body;

    // Password validation
    if (Password.length !== 6) { // Password length validation
        return res.status(400).send('<h1>Password must be exactly 6 characters.</h1>');
    }

    // Call the stored procedure
    const query = 'CALL signupUser(?, ?, ?, ?, ?)';
    db.query(query, [Name, Email, DepartmentName, Role, Password], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).send('<h1>Email is already registered.</h1>');
            }
            console.error('Error during signup:', err);
            return res.status(500).send('<h1>Signup failed.</h1>');
        }

        // If everything is successful, redirect to the home page or other post-signup action
        res.redirect('/');
    });
});

app.get('/procurement-manager-dashboard', (req, res) => {
    const tableType = req.query.table || 'vendor'; // Default to 'vendor' table if no query parameter is provided

    const queries = {
        vendor: 'SELECT * FROM Vendor',
        certification: 'SELECT * FROM ComplianceCertifications',
        contract: 'SELECT * FROM Contract',
        expiredContracts: 'SELECT * FROM Contract WHERE ExpiryDate < CURDATE()',
    };

    const query = queries[tableType];
    if (!query) {
        return res.status(400).send('Invalid table type.');
    }

    db.query(query, (err, results) => {
        if (err) {
            console.error(`Error fetching ${tableType} data:`, err);
            return res.status(500).send(`Error fetching ${tableType} data.`);
        }

        let tableHTML = '';
        switch (tableType) {
            case 'vendor':
                tableHTML = `
                    <table border="1">
                        <tr>
                            <th>VendorID</th>
                            <th>Organization Name</th>
                            <th>Service Categories</th>
                            <th>Contact Name</th>
                            <th>Contact Email</th>
                            <th>Contact Phone</th>
                            <th>Contact Address</th>
                            <th>CNIC Number</th>
                            <th>Actions</th>
                        </tr>
                        ${results
                            .map(
                                (vendor) => `
                            <tr>
                                <td>${vendor.VendorID}</td>
                                <td>${vendor.OrganizationName}</td>
                                <td>${vendor.ServiceCategories}</td>
                                <td>${vendor.ContactName}</td>
                                <td>${vendor.ContactEmail}</td>
                                <td>${vendor.ContactPhone}</td>
                                <td>${vendor.ContactAddress}</td>
                                <td>${vendor.CNICNumber}</td>
                                <td>
                                    <button onclick="location.href='/edit-vendor/${vendor.VendorID}'">Update</button>
                                    <button onclick="if(confirm('Are you sure?')) location.href='/delete-vendor/${vendor.VendorID}'">Delete</button>
                                </td>
                            </tr>`
                            )
                            .join('')}
                    </table>`;
                break;
            case 'certification':
                tableHTML = `
                    <table border="1">
                        <tr>
                            <th>VendorID</th>
                            <th>Certification Number</th>
                            <th>Certificate Name</th>
                            <th>Issued By Company</th>
                            <th>Attested By Person</th>
                            <th>Issue Date</th>
                            <th>Expiry Date</th>
                            <th>Status</th>
                        </tr>
                        ${results
                            .map(
                                (cert) => `
                            <tr>
                                <td>${cert.VendorID}</td>
                                <td>${cert.CertificationNumber}</td>
                                <td>${cert.CertificateName}</td>
                                <td>${cert.IssuedByCompany}</td>
                                <td>${cert.AttestedByPerson}</td>
                                <td>${cert.IssueDate}</td>
                                <td>${cert.ExpiryDate}</td>
                                <td>${cert.Status}</td>
                            </tr>`
                            )
                            .join('')}
                    </table>`;
                break;
            case 'contract':
                tableHTML = `
                    <table border="1">
                        <tr>
                            <th>ContractID</th>
                            <th>VendorID</th>
                            <th>DepartmentID</th>
                            <th>Terms</th>
                            <th>ContractType</th>
                            <th>Conditions</th>
                            <th>Status</th>
                            <th>SpecialClauses</th>
                            <th>RenewalDate</th>
                            <th>ExpiryDate</th>
                            <th>IsRenewed</th>
                            <th>IsContractArchived</th>
                            <th>ArchivedDate</th>
                            <th>Reviews</th>
                            <th>Actions</th>
                        </tr>
                        ${results
                            .map(
                                (contract) => `
                            <tr>
                                <td>${contract.ContractID}</td>
                                <td>${contract.VendorID}</td>
                                <td>${contract.DepartmentID}</td>
                                <td>${contract.Terms}</td>
                                <td>${contract.ContractType}</td>
                                <td>${contract.Conditions}</td>
                                <td>${contract.Status}</td>
                                <td>${contract.SpecialClauses}</td>
                                <td>${contract.RenewalDate ? new Date(contract.RenewalDate).toLocaleDateString() : 'N/A'}</td>
                                <td>${contract.ExpiryDate ? new Date(contract.ExpiryDate).toLocaleDateString() : 'N/A'}</td>
                                <td>${contract.IsRenewed}</td>
                                <td>${contract.IsContractArchived}</td>
                                <td>${contract.ArchivedDate ? new Date(contract.ArchivedDate).toLocaleDateString() : 'N/A'}</td>
                                <td>${contract.Reviews}</td>
                                <td>
                                    <button onclick="location.href='/edit-contract/${contract.ContractID}'">Edit</button>
                                </td>
                            </tr>`
                            )
                            .join('')}
                    </table>`;
                break;
            case 'expiredContracts':
                tableHTML = `
                    <table border="1">
                        <tr>
                            <th>ContractID</th>
                            <th>VendorID</th>
                            <th>Terms</th>
                            <th>RenewalDate</th>
                            <th>Status</th>
                            <th>Reviews</th>
                        </tr>
                        ${results
                            .map(
                                (contract) => `
                            <tr>
                                <td>${contract.ContractID}</td>
                                <td>${contract.VendorID}</td>
                                <td>${contract.Terms}</td>
                                <td>${contract.RenewalDate ? new Date(contract.RenewalDate).toLocaleDateString() : 'N/A'}</td>
                                <td>${contract.Status}</td>
                                <td>${contract.Reviews}</td>
                            </tr>`
                            )
                            .join('')}
                    </table>`;
                break;
        }

        res.send(`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procurement Manager Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            background: linear-gradient(135deg, #007bff, #4dabf7);
            color: white;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .dashboard-header h1 {
            font-weight: 300;
            display: flex;
            align-items: center;
        }
        .dashboard-header i {
            margin-right: 15px;
        }
        .btn-custom {
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .btn-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card-action {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        .table-responsive {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .table {
            margin-bottom: 0;
        }
        .table thead {
            background-color: #f8f9fa;
        }
        @media (max-width: 768px) {
            .btn-group-vertical {
                width: 100%;
            }
            .btn-custom {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-header text-center">
        <div class="container">
            <h1>
                <i class="fas fa-chart-line"></i>
                Procurement Manager Dashboard
            </h1>
        </div>
    </div>

    <div class="container mt-4">
        <div class="card-action">
            <div class="btn-group btn-group-lg d-flex flex-wrap mb-4" role="group" aria-label="Dashboard Actions">
                <button onclick="location.href='/add-vendor-form'" class="btn btn-primary btn-custom flex-grow-1 m-1">
                    <i class="fas fa-plus-circle"></i> Add Vendor
                </button>
                <button onclick="location.href='/procurement-manager-dashboard?table=vendor'" class="btn btn-primary btn-custom flex-grow-1 m-1">
                    <i class="fas fa-table"></i> Vendor Table
                </button>
                <button onclick="location.href='/procurement-manager-dashboard?table=certification'" class="btn btn-primary btn-custom flex-grow-1 m-1">
                    <i class="fas fa-certificate"></i> Certification Table
                </button>
                <button onclick="location.href='/procurement-manager-dashboard?table=contract'" class="btn btn-primary btn-custom flex-grow-1 m-1">
                    <i class="fas fa-file-contract"></i> Contract Table
                </button>
                <button onclick="window.location.href='/add-notification'" class="btn btn-primary btn-custom flex-grow-1 m-1">
                    <i class="fas fa-bell"></i> Add Notification
                </button>
                <button onclick="location.href='/procurement-manager-dashboard?table=expiredContracts'" class="btn btn-warning btn-custom flex-grow-1 m-1">
                    <i class="fas fa-exclamation-triangle"></i> Expired Contracts
                </button>
                <button onclick="location.href='/logout'" class="btn btn-danger btn-custom flex-grow-1 m-1">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>

        <div class="table-responsive mt-4">
            <!-- Dynamic Table Content -->
            ${tableHTML}
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
        `);
    });
});


// Handle Add Vendor

app.get('/add-vendor-form', (req, res) => {
    res.send(`
        <form action="/submit" method="POST">
            <h2>Vendor Information</h2>
            Organization Name: <input type="text" name="organizationName" required><br>
            Service Categories: <input type="text" name="serviceCategories"><br>
            Contact Name: <input type="text" name="contactName"><br>
            Contact Email: <input type="email" name="contactEmail" required><br>
            Contact Phone: <input type="text" name="contactPhone" required><br>
            Contact Address: <input type="text" name="contactAddress"><br>
            CNIC Number: <input type="text" name="cnicNumber" required><br>
            
            <h2>Compliance Certification</h2>
            Certification Number: <input type="text" name="certificationNumber" required><br>
            Certificate Name: <input type="text" name="certificateName" required><br>
            Issued By Company: <input type="text" name="issuedByCompany" required><br>
            Attested By Person: <input type="text" name="attestedByPerson" required><br>
            Issue Date: <input type="date" name="issueDate" required><br>
            Expiry Date: <input type="date" name="expiryDate" required><br>
            Status: 
            <select name="status" required>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Under Review">Under Review</option>
            </select><br>
            <button type="submit">Submit</button>
        </form>
    `);
});


app.post('/submit', (req, res) => {
    const {
        organizationName,
        serviceCategories,
        contactName,
        contactEmail,
        contactPhone,
        contactAddress,
        cnicNumber,
        certificationNumber,
        certificateName,
        issuedByCompany,
        attestedByPerson,
        issueDate,
        expiryDate,
        status,
    } = req.body;

    // Insert Vendor
    const vendorQuery = `
        INSERT INTO Vendor 
        (OrganizationName, ServiceCategories, ContactName, ContactEmail, ContactPhone, ContactAddress, CNICNumber) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(
        vendorQuery,
        [organizationName, serviceCategories, contactName, contactEmail, contactPhone, contactAddress, cnicNumber],
        (err, vendorResult) => {
            if (err) {
                console.error('Error inserting vendor:', err);
                return res.status(500).send('Error inserting vendor.');
            }

            const vendorID = vendorResult.insertId;

            // Insert Compliance Certification
            const certificationQuery = `
                INSERT INTO ComplianceCertifications 
                (CertificationNumber, CertificateName, IssuedByCompany, AttestedByPerson, IssueDate, ExpiryDate, Status, VendorID) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;

            db.query(
                certificationQuery,
                [certificationNumber, certificateName, issuedByCompany, attestedByPerson, issueDate, expiryDate, status, vendorID],
                (err) => {
                    if (err) {
                        console.error('Error inserting certification:', err);
                        return res.status(500).send('Error inserting certification.');
                    }

                    // Successful insertion
                    res.redirect('/procurement-manager-dashboard'); // Redirect on success
                }
            );
        }
    );
});

// Handle Delete Vendor
app.get('/delete-vendor/:id', (req, res) => {
    const { id } = req.params;
    const deleteQuery = 'DELETE FROM Vendor WHERE VendorID = ?';
    db.query(deleteQuery, [id], (err) => {
        if (err) {
            console.error('Error deleting vendor:', err);
            return res.status(500).send('Error deleting vendor.');
        }
        res.redirect('/procurement-manager-dashboard');
    });
});


// Handle vendor deletion via POST (recommended method)
app.post('/delete-vendor/:id', (req, res) => {
    const { id } = req.params;
    const deleteVendorQuery = 'DELETE FROM Vendor WHERE VendorID= ?';

    db.query(deleteVendorQuery, [id], (err) => {
        if (err) {
            console.error('Error deleting vendor:', err);
            return res.status(500).send('Error deleting vendor.');
        }
        res.redirect('/procurement-manager-dashboard');
    });
});
// Route to display the edit form for a specific vendor
app.get('/edit-vendor/:vendorId', (req, res) => {
    const vendorId = req.params.vendorId;
    
    const query = 'SELECT * FROM Vendor WHERE VendorID = ?';
    db.query(query, [vendorId], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error fetching vendor:', err);
            return res.status(500).send('Error fetching vendor data.');
        }
        
        const vendor = results[0];

        // Create the form to edit vendor details
        res.send(`
            <h1>Edit Vendor</h1>
            <form action="/update-vendor/${vendorId}" method="POST">
                <label for="serviceCategories">Service Categories:</label>
                <input type="text" id="serviceCategories" name="serviceCategories" value="${vendor.ServiceCategories}" required><br><br>

                <label for="contactEmail">Contact Email:</label>
                <input type="email" id="contactEmail" name="contactEmail" value="${vendor.ContactEmail}" required><br><br>

                <label for="contactPhone">Contact Phone:</label>
                <input type="text" id="contactPhone" name="contactPhone" value="${vendor.ContactPhone}" required><br><br>

                <label for="contactAddress">Contact Address:</label>
                <textarea id="contactAddress" name="contactAddress" required>${vendor.ContactAddress}</textarea><br><br>

                <button type="submit">Update Vendor</button>
            </form>
        `);
    });
});
// Route to handle the form submission and update vendor data
app.post('/update-vendor/:vendorId', (req, res) => {
    const vendorId = req.params.vendorId;
    const { serviceCategories, contactEmail, contactPhone, contactAddress } = req.body;
    
    const query = `
        UPDATE Vendor
        SET ServiceCategories = ?, ContactEmail = ?, ContactPhone = ?, ContactAddress = ?
        WHERE VendorID = ?
    `;
    
    db.query(query, [serviceCategories, contactEmail, contactPhone, contactAddress, vendorId], (err, results) => {
        if (err) {
            console.error('Error updating vendor:', err);
            return res.status(500).send('Error updating vendor.');
        }

        // Redirect back to the dashboard after successful update
        res.redirect('/procurement-manager-dashboard');
    });
});
// Route to display the add notification form

app.get('/add-notification', (req, res) => {
    // SQL query to get contracts expiring in the next 30 days
    const notificationQuery = `
        SELECT 
            u.UserID,
            u.Name,
            u.Email,
            u.Role,
            v.OrganizationName,
            v.ContactName,
            v.ContactEmail,
            c.ContractID,
            c.ExpiryDate
        FROM 
            User u
        JOIN 
            Vendor v ON u.UserID = v.UserID
        JOIN 
            Contract c ON v.VendorID = c.VendorID
        WHERE 
            c.ExpiryDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    `;

    db.query(notificationQuery, (err, results) => {
        if (err) {
            console.error('Error fetching contracts:', err);
            return res.status(500).send('Error fetching contract data.');
        }

        // Loop through each contract expiring soon and insert a notification
        results.forEach(contract => {
            const notificationMessage = `Reminder: The contract with ${contract.OrganizationName} is expiring on ${contract.ExpiryDate}.`;

            const insertNotificationQuery = `
                INSERT INTO Notification (UserID, Message, Date)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            `;
            
            db.query(insertNotificationQuery, [contract.UserID, notificationMessage], (insertErr) => {
                if (insertErr) {
                    console.error('Error inserting notification:', insertErr);
                    return res.status(500).send('Error inserting notification.');
                }
            });
        });

        // After inserting notifications, send a response with the success message
        res.send(`
            <h1>Notifications Added</h1>
            <p>Notifications for contracts expiring in the next 30 days have been successfully added.</p>
            <button onclick="window.location.href='/procurement-manager-dashboard'">Go to Dashboard</button>
        `);
    });
});
app.get('/edit-contract/:contractID', (req, res) => {
    const contractID = req.params.contractID;

    // Fetch contract details based on the ContractID
    const contractQuery = 'SELECT * FROM Contract WHERE ContractID = ?';
    db.query(contractQuery, [contractID], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error fetching contract:', err);
            return res.status(500).send('Contract not found.');
        }

        const contract = results[0];

        // Render the contract edit form with current contract data
        res.send(`
            <h1>Edit Contract Details</h1>
            <form action="/update-contract/${contractID}" method="POST">
                <label for="terms">Terms:</label>
                <textarea name="terms" required>${contract.Terms}</textarea><br>

                <label for="renewalDate">Renewal Date:</label>
                <input type="date" name="renewalDate" value="${contract.RenewalDate}" required><br>

                <label for="status">Status:</label>
                <select name="status" required>
                    <option value="Approved" ${contract.Status === 'Approved' ? 'selected' : ''}>Approved</option>
                    <option value="Rejected" ${contract.Status === 'Rejected' ? 'selected' : ''}>Rejected</option>
                </select><br>

                <label for="reviews">Reviews:</label>
                <textarea name="reviews" required>${contract.Reviews}</textarea><br>

                <input type="submit" value="Update Contract">
            </form>
            <br>
            <button onclick="location.href='/procurement-manager-dashboard'">Back to Dashboard</button>
        `);
    });
});
app.post('/update-contract/:contractID', (req, res) => {
    const contractID = parseInt(req.params.contractID, 10); // Ensure contractID is an integer
    const { terms, renewalDate, status, reviews } = req.body;

    if (isNaN(contractID)) {
        return res.status(400).send('Invalid Contract ID');
    }

    const procedureCall = `CALL UpdateContractDetails(?, ?, ?, ?, ?)`;
    db.query(procedureCall, [contractID, terms, renewalDate, status, reviews], (err, result) => {
        if (err) {
            console.error('Error calling stored procedure:', err);
            return res.status(500).send('Failed to update contract.');
        }
        res.redirect('/procurement-manager-dashboard');
    });
});

// Start the server
app.listen(8080, () => {
    console.log('Server running on http://localhost:8080');
});