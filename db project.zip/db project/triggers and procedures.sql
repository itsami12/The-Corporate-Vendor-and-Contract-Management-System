USE project;
DELIMITER //

CREATE PROCEDURE UpdateContractDetails(
    IN p_ContractID INT,
    IN p_Terms TEXT,
    IN p_RenewalDate DATE,
    IN p_Status ENUM('Approved', 'Rejected'),
    IN p_Reviews TEXT
)
BEGIN
    IF p_ContractID IS NULL OR p_ContractID <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Contract ID';
    END IF;

    UPDATE Contract
    SET 
        Terms = p_Terms,
        RenewalDate = p_RenewalDate,
        Status = p_Status,
        Reviews = p_Reviews
    WHERE ContractID = p_ContractID;
END;

DELIMITER //

CREATE PROCEDURE AddVendorPerformance(
    IN p_VendorID INT,
    IN p_PerformancePeriod VARCHAR(255),
    IN p_DeliveryTimeliness DECIMAL(5, 2),
    IN p_ServiceQuality DECIMAL(5, 2),
    IN p_Pricing DECIMAL(5, 2),
    IN p_ComplianceAdherence DECIMAL(5, 2),
    IN p_PerformanceRating DECIMAL(5, 2),
    IN p_Remarks TEXT
)
BEGIN
    INSERT INTO VendorPerformance (
        VendorID, 
        PerformancePeriod, 
        DeliveryTimeliness, 
        ServiceQuality, 
        Pricing, 
        ComplianceAdherence, 
        PerformanceRating, 
        Remarks
    )
    VALUES (
        p_VendorID, 
        p_PerformancePeriod, 
        p_DeliveryTimeliness, 
        p_ServiceQuality, 
        p_Pricing, 
        p_ComplianceAdherence, 
        p_PerformanceRating, 
        p_Remarks
    );
END //

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE `signupUser`(
    IN p_Name VARCHAR(255),
    IN p_Email VARCHAR(255),
    IN p_DepartmentName VARCHAR(255),
    IN p_Role VARCHAR(255),
    IN p_Password VARCHAR(255)
)
BEGIN
    -- Insert into User table
    INSERT INTO User (Name, Email, DepartmentName, Role, Password)
    VALUES (p_Name, p_Email, p_DepartmentName, p_Role, p_Password);
    
    -- Get the last inserted UserID
    SET @userId = LAST_INSERT_ID();
    
    -- Insert into Department table
    INSERT INTO Department (DepartmentName, UserID)
    VALUES (p_DepartmentName, @userId);
END $$

DELIMITER ;

DELIMITER $$
CREATE TRIGGER check_Contract_Renewals
AFTER  INSERT ON contract
FOR EACH ROW
BEGIN
    DECLARE threshold_date DATE;
    SET threshold_date = DATE_ADD(CURDATE(), INTERVAL 30 DAY);
     IF NEW.ExpiryDate <= threshold_date  THEN
       
        INSERT INTO Notification (UserID, Message, Date)
        SELECT 
            v.UserID, 
            CONCAT('Your contract with ContractID: ', NEW.ContractID, 
                   ' is expiring soon. Please review the terms for renewal.'), 
            NOW()
        FROM Vendor v
        WHERE v.VendorID = NEW.VendorID;
    END IF;
END$$

DELIMITER ;
DELIMITER //

CREATE TRIGGER check_budget_alert
AFTER UPDATE ON PurchaseOrder
FOR EACH ROW
BEGIN
   
    IF NEW.TotalCost > NEW.BudgetID THEN
        UPDATE PurchaseOrder
        SET IsWithinBudget = 0, BudgetDeviation = NEW.TotalCost - NEW.BudgetID
        WHERE PurchaseOrderID = NEW.PurchaseOrderID;
        INSERT INTO Notification (UserID, Message)
        SELECT u.UserID, CONCAT('Purchase Order ID ', NEW.PurchaseOrderID, ' has exceeded its assigned budget by ', NEW.TotalCost - NEW.BudgetID)
        FROM Vendor v
        JOIN User u ON v.UserID = u.UserID
        WHERE v.VendorID = NEW.VendorID
        LIMIT 1;  
    END IF;
END //

DELIMITER ;

