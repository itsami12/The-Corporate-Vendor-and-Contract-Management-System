DROP DATABASE IF EXISTS project;
CREATE DATABASE project ;
USE project;
CREATE TABLE User (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    DepartmentName VARCHAR(100) NOT NULL,
    Role ENUM('Department Head','Procurement Manager', 'Vendor','Budget Manager','Finance Team') Not NUll,
    Password VARCHAR(255) NOT NULL,
    CONSTRAINT password_length CHECK (CHAR_LENGTH(Password) = 6), -- Constraint for 6-character password
	CONSTRAINT CK_Email CHECK (Email LIKE '%@gmail.com')
);
CREATE TABLE Vendor (
    VendorID INT PRIMARY KEY AUTO_INCREMENT NOT NULL UNIQUE,
    OrganizationName VARCHAR(255) NOT NULL,
    ServiceCategories VARCHAR(255),
    ContactName VARCHAR(100),
    ContactEmail VARCHAR(100) NOT NULL,
    ContactPhone VARCHAR(20) NOT NULL,
    ContactAddress VARCHAR(255),
    CNICNumber VARCHAR(20) NOT NULL UNIQUE,
     UserID INT, 
    -- Constraints for CNIC Number (must be 13 digits)
    CONSTRAINT CK_CNICNumber CHECK (CHAR_LENGTH(CNICNumber) = 13 AND CNICNumber REGEXP '^[0-9]+$'),
    -- Constraints for Contact Phone (must be 11 digits)
    CONSTRAINT CK_ContactPhone CHECK (CHAR_LENGTH(ContactPhone) = 11 AND ContactPhone REGEXP '^[0-9]+$'),
    -- Constraint for Contact Email (must end with '@gmail.com')
    CONSTRAINT CK_ContactEmail CHECK (ContactEmail LIKE '%@gmail.com'),
     FOREIGN KEY (UserID) REFERENCES User(UserID)  -- Link to User table
);
CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY AUTO_INCREMENT not null  unique,
    DepartmentName  VARCHAR(100) NOT NULL,
    UserID INT,  -- References UserID from User table
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);


CREATE TABLE ComplianceCertifications (
    CertificationNumber VARCHAR(50) PRIMARY KEY,
    CertificateName VARCHAR(255) NOT NULL,
    IssuedByCompany VARCHAR(255) NOT NULL,
    AttestedByPerson VARCHAR(100) NOT NULL,
    IssueDate DATE NOT NULL,
    ExpiryDate DATE NOT NULL,
    Status VARCHAR(50) CHECK (Status IN ('Active', 'Inactive', 'Under Review')) NOT NULL,
    VendorID INT,
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID) ON DELETE CASCADE
);
-- 3. Vendor Performance Table
CREATE TABLE VendorPerformance (
    PerformanceID INT PRIMARY KEY AUTO_INCREMENT not null  unique,
    VendorID INT,
    PerformancePeriod VARCHAR(50),
    DeliveryTimeliness DECIMAL(5,2),
    ServiceQuality DECIMAL(5,2),
    Pricing DECIMAL(5,2),
    ComplianceAdherence DECIMAL(5,2),
    PerformanceRating DECIMAL(5,2),
    Remarks TEXT,
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID) ON DELETE CASCADE
);

CREATE TABLE Contract (
    ContractID  INT PRIMARY KEY AUTO_INCREMENT not null  unique,
    VendorID INT not null,
    DepartmentID INT not null,
    Terms TEXT not null,
    ContractType VARCHAR(50) CHECK (ContractType IN ('Fixed-Term', 'Open-Ended')) not null,
    Conditions TEXT not null,
    Status VARCHAR(50) CHECK (Status IN ('Approved', 'Rejected')),
    SpecialClauses TEXT not null,
    RenewalDate DATE not null,
    ExpiryDate DATE not null,
    IsRenewed VARCHAR(50) not null,
    IsContractArchived VARCHAR(50)  not null,
    ArchivedDate DATE ,
    Reviews TEXT,
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID) ON DELETE CASCADE,
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID) ON DELETE CASCADE
);
CREATE TABLE Budget (
    BudgetID INT PRIMARY KEY AUTO_INCREMENT not null  unique,
    VendorID INT,
    ContractID INT,
    DepartmentID INT,
    ExpenseCategory VARCHAR(100),
    TotalAmount DECIMAL(10,2),
    SpentAmount DECIMAL(10,2),
    RemainingAmount DECIMAL(10,2),
    Date DATE,
    ExpenditureStatus VARCHAR(50) CHECK (ExpenditureStatus IN ('Pending', 'Approved', 'Paid')),
    OverspendingStatus BIT DEFAULT 0,
    AlertThreshold DECIMAL(10,2),
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID) ON DELETE CASCADE,
    FOREIGN KEY (ContractID) REFERENCES Contract(ContractID) ON DELETE CASCADE,
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID) ON DELETE CASCADE
);
CREATE TABLE PurchaseOrder (
    PurchaseOrderID INT PRIMARY KEY AUTO_INCREMENT not null  unique,
    DepartmentID INT,
    VendorID INT,
    ItemDetails TEXT,
    Quantity INT,
    ServicesOrdered TEXT,
    TotalCost DECIMAL(10,2),
    Status VARCHAR(50) CHECK (Status IN ('Submitted', 'Not Submitted')) not null,
    BudgetID INT,
    IsWithinBudget BIT DEFAULT 1,
    BudgetDeviation DECIMAL(10,2),
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID) ON DELETE CASCADE,
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID) ON DELETE CASCADE,
    FOREIGN KEY (BudgetID) REFERENCES Budget(BudgetID) ON DELETE CASCADE
);





CREATE TABLE Notification (
    NotificationID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    Message TEXT ,
    Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);
CREATE TABLE Task (
    TaskID INT AUTO_INCREMENT PRIMARY KEY,
    AssignedTo INT NOT NULL,
    Description TEXT NOT NULL,
    Status ENUM('Pending', 'Completed') DEFAULT 'Pending',
    DueDate DATE,
    FOREIGN KEY (AssignedTo) REFERENCES User(UserID)
);
CREATE TABLE AuditLog (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    ActionType VARCHAR(255) NOT NULL,
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);
-- Insert User Data
INSERT INTO User (Name, Email, DepartmentName, Role, Password)
VALUES 
('Ali Raza', 'ali.raza@gmail.com', 'Finance', 'Budget Manager', '123456'),
('Ahmed Khan', 'ahmed.khan@gmail.com', 'IT', 'Procurement Manager', '654321'),
('Sara Ali', 'sara.ali@gmail.com', 'Operations', 'Vendor', 'abcdef');

-- Inserting data into the Vendor table
INSERT INTO Vendor (OrganizationName, ServiceCategories, ContactName, ContactEmail, ContactPhone, ContactAddress, CNICNumber,UserID)
VALUES 
('ABC Technologies', 'IT Services, Software Development', 'Ahmed Khan', 'ahmed.khan@gmail.com', '30012345671', 'Lahore, Punjab', '1234567890123',2),
('XYZ Solutions', 'Consultancy, Project Management', 'Sara Ali', 'sara.ali@gmail.com', '13002345678', 'Karachi, Sindh', '2345678901234',3),
('Pak Traders', 'Wholesale Distribution', 'Bilal Shah', 'bilal.shah@gmail.com', '30103456789', 'Islamabad, Islamabad', '3456789012345',NULL);



-- Insert Department Data
INSERT INTO Department (DepartmentName, UserID)
VALUES 
('Finance', 1),
('IT', 2),
('Operations', 3);
-- Insert ComplianceCertifications Data
INSERT INTO ComplianceCertifications (CertificationNumber, CertificateName, IssuedByCompany, AttestedByPerson, IssueDate, ExpiryDate, Status, VendorID)
VALUES 
('C12345', 'ISO 9001', 'Pak Standards Authority', 'Ali Raza', '2023-01-01', '2025-01-01', 'Active', 1),
('C23456', 'ISO 14001', 'Pak Standards Authority', 'Nida Khan', '2022-06-01', '2024-06-01', 'Under Review', 2),
('C34567', 'OHSAS 18001', 'Pak Standards Authority', 'Mehmood Iqbal', '2021-11-01', '2023-11-01', 'Inactive', 3);

-- Insert VendorPerformance Data
INSERT INTO VendorPerformance (VendorID, PerformancePeriod, DeliveryTimeliness, ServiceQuality, Pricing, ComplianceAdherence, PerformanceRating, Remarks)
VALUES 
(1, 'Q1 2024', 90.5, 88.0, 85.0, 95.0, 90.0, 'Good performance in terms of delivery and service quality.'),

(3, 'Q1 2024', 95.0, 90.0, 92.0, 93.0, 94.0, 'Excellent adherence to compliance and quality.');

-- Insert Contract Data
INSERT INTO Contract (VendorID, DepartmentID, Terms, ContractType, Conditions, Status, SpecialClauses, RenewalDate, ExpiryDate, IsRenewed, IsContractArchived, ArchivedDate)
VALUES 
(1, 2, 'Maintain IT infrastructure for 1 year.', 'Fixed-Term', 'Confidentiality Clause', 'Approved', 'Data Security Agreement', '2024-11-5', '2024-12-05', 'NO', 'NO', Null),
(2, 1, 'Provide consultancy services for 6 months.', 'Fixed-Term', 'NDA Clause', 'Approved', 'Risk Management Framework', '2024-07-01', '2024-12-05', 'NO', 'NO', Null),
(3, 3, 'Supply goods for 3 months.', 'Open-Ended', 'No Special Conditions', 'Rejected', 'None', '2024-07-01', '2024-03-31', 'NO', 'YES', '2024-03-31');
-- Insert Budget Data
INSERT INTO Budget (VendorID, ContractID, DepartmentID, ExpenseCategory, TotalAmount, SpentAmount, RemainingAmount, Date, ExpenditureStatus, AlertThreshold)
VALUES 
(1, 1, 2, 'IT Maintenance', 100000.00, 50000.00, 50000.00, '2024-05-01', 'Pending', 20000.00),
(2, 2, 1, 'Consultancy Fees', 50000.00, 30000.00, 20000.00, '2024-06-01', 'Approved', 10000.00),
(3, 3, 3, 'Product Purchase', 200000.00, 100000.00, 100000.00, '2024-04-01', 'Paid', 50000.00);

-- Insert PurchaseOrder Data
INSERT INTO PurchaseOrder (DepartmentID, VendorID, ItemDetails, Quantity, ServicesOrdered, TotalCost, Status, BudgetID, IsWithinBudget, BudgetDeviation)
VALUES 
(2, 1, 'Servers and software licenses', 10, 'Software Development', 40000.00, 'Submitted', 1, 1, 0),
(1, 2, 'Consultancy Services for Risk Assessment', 5, 'Consultancy', 20000.00, 'Not Submitted', 2, 0, 0),
(3, 3, 'Bulk Wholesale Products', 100, 'Wholesale Distribution', 100000.00, 'Submitted', 3, 1, 0);


-- Insert Notification Data
INSERT INTO Notification (UserID, Message)
VALUES 
(2, 'New performance report available for review.'),
(3, 'You have a pending contract renewal.');

-- Insert Task Data
INSERT INTO Task (AssignedTo, Description, Status, DueDate)
VALUES 
(1, 'Review the new vendor contract.', 'Pending', '2024-12-01'),
(2, 'Approve budget expenditure for Q1.', 'Completed', '2024-05-01'),
(3, 'Provide service update for the last quarter.', 'Pending', '2024-06-01');

-- Insert AuditLog Data
INSERT INTO AuditLog (UserID, ActionType)
VALUES 
(1, 'Created a new contract for Vendor ABC Technologies.'),
(2, 'Updated the performance rating for Vendor XYZ Solutions.'),
(3, 'Submitted a new purchase order for Pak Traders.');
